package demo1ANDornotoperators;

public class demo1ANDornotoperators {

	public static void main(String[] args) {
		
		
		
		Object[] a= {9, 88L,3.5f,1.234,true,'c',"chandrika"};
		
	}
	
}
		
	    