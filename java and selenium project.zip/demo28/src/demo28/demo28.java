package demo28;
 import java.util.Scanner;
public class demo28 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		String CorrectUsername = "Chandrika";
		String Correctpass = "Chandu.30@";
		
		// this is used for the number of try in java for the user to use to check how many times they use it and store it 

		
		String Username, password;
		
		int attempts = 0;
		

		while(attempts < 3) {
			
			System.out.println("Enter Username");
			Username = sc.nextLine();
			
			System.out.println("Enter Password");
			password = sc.nextLine();
			
		if(Username.equals(CorrectUsername)&& password.equals(Correctpass)){
			
			System.out.println("Logical is Successful");
			
			break;
			
		} else {
			
			attempts ++;
			
			System.out.println("Wrong credentials"+ (3- attempts));
			
		}
		 if (attempts == 3) {
			 
			 System.out.println("Account is blocked");
		 }
			
		}
				 {
		}
	}

}
