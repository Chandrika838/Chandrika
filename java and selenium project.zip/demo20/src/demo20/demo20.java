package demo20;

public class demo20 {

	public static void main(String[] args) {
		
		
        BankAccount b1=  new BankAccount();
        
        b1.name = "Chandrika";
        b1.Balance = 3000;
        
        b1. display();
        b1. deposit(5000);
        
	}

}


class BankAccount {
	
	String name;
	double Balance;
	
	
	void deposit(double amount) {
		
		Balance += amount ;	
	}
       void display() {
    	   
    	   System.out.println("Name :" + name  + Balance);
       }

}
