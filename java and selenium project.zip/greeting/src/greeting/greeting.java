package greeting;

public class greeting {

	static void welcome() // method created  {
		System.out.println("Welcome to java"); // result 
	}


public static void main (String[]agrs) {
	
	welcome();// method call 
}

}