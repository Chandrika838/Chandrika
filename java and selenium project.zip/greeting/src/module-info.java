/**
 * 
 */
/**
 * 
 */
module greeting {
}