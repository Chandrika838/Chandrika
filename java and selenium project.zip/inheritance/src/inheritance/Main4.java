package inheritance;

public class Main4 {

	public static void main(String[] args) {
	
		// create a object 
		
		Abstractvehicle v = new  bike ();
		v.start();

	}

}
