package inheritance;

abstract class Employee {

    String name;

    Employee(String n) {
        name = n;
    }

    abstract void calculateSalary();
}

class Developer extends Employee {

    int Salary = 5000;

    Developer(String n) {
        super(n);
    }

    void calculateSalary() {
        System.out.println("Developer " + name + " Salary: " + Salary);
    }
}

class Tester extends Employee {

    int Salary = 40000;

    Tester(String n) {
        super(n);
    }

    void calculateSalary() {   // ✅ correct spelling
        System.out.println("Tester " + name + " Salary: " + Salary);
    }



    }
