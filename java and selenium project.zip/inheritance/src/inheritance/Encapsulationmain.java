package inheritance;

public class Encapsulationmain {

	public static void main(String[] args) {
		Encapsulation obj = new Encapsulation(1000);
		
		obj.deposit(5000);
		obj.withdraw(4000);
		System.out.println("Final balance: " + obj.getbalance());
		
	}

}
