package inheritance;

public class Main {

	public static void main(String[] args) {
		
		// method 
		Car c = new Car();
		
		System.out.println("Speed:" + c.speed);
		System.out.println("brand:" + c.brand);
		
	}

}
