package inheritance;

public class Main6 {

	public static void main(String[] args) {
	
		// polymorphism 
		
		// UPI payment 
		
		// creating the object for this with the method 

		
	Payment1 c = new UPIPayment(2000);
		c.pay();
		c.receipt();
		
		System.out.println(" ----------------");
		
		// card Payment
		
		 c = new CardPayment(100 , "1234566789");
		 c.pay();
		 c.receipt();
	}

}
