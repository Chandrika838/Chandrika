package inheritance;

public class Main5 {

	public static void main(String[] args) {
		
		Employee e1 = new Developer("Chandrika");
		Employee e2 = new Tester("Anu");
		
	}

}
