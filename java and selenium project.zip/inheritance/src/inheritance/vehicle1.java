package inheritance;

public class vehicle1 {
 // method 
	
	void start() {
		
		System.out.println("Vehicle start");
		
	}
}

class Bike extends vehicle1 {
	
	void start() {
		
		System.out.println("Bike started");
		
	}
}
class Motor extends vehicle1 {
	
	void start() {
		
		System.out.println("Motor Started");
		

	
	
}
	}
