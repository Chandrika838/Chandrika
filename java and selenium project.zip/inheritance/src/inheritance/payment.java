package inheritance;

abstract class Payment {
	
	abstract void pay();
	
	}

class OnlinePayment extends Payment {
	
	public void pay() {
		
		System.out.println("Paid using UPI");
	}
}

class Bank extends Payment {
	
	public void pay() {
		
		System.out.println("Paid using Card");
	}

}