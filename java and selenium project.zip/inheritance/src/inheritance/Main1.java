package inheritance;

public class Main1 {

	public static void main(String[] args) {
		
// object of the class 
		
		polymorphism c  = new polymorphism();
		
		System.out.println(c.add(4, 5));
		System.out.println(c.add(2, 4, 5));
		
		}
	}


