package inheritance;

// abstract method 

abstract  class Payment1 {
	
	// im giving the amount name here 
	
	int amount ;
	
	// constructor we need to use the constructor because we have created the amount number here 
	
	Payment1(int amount) {
		
	this.amount  = amount ;
	
	System.out.println("Payment created with the amount :" + amount);
	}
	
	abstract void pay();
	
	// method overloading 
	
	void receipt() {
		
		System.out.println("Basic receipt generated");	
	}
	
		void receipt(String type) { // we need to create the parameter in the constructor 
			
		System.out.println("Receipt is created :" + type);	
		
	}
}
		// class 1

	class UPIPayment extends Payment1 {
		
		String upiID; // method 
		
		//  constructor  using super() and this()
		
		UPIPayment(int amount) {
			
			this(amount, " default@upi"); // this ()
		
	}
		
		
	UPIPayment(int amount, String upiID) { // parameter in the constructor 
		
		super(amount); // parenting constructor 
		this.upiID = upiID;
	}
 	
	
	// method overriding 
	
	void pay() {
		
		System.out.println("Paid " + amount + "using UPI: " + upiID);
	}
}
	
	
	
	class CardPayment extends Payment1 {
	
	String cardnumber;
	
	CardPayment (int amount,  String cardnumber) {
		
		super(amount);
		this.cardnumber = cardnumber;
		
	}
	


// Method overidding 

void Pay() {
	
	System.out.println("Paid " + amount + "Using Card :" + cardnumber );
	
}



@Override
void pay() {
	// TODO Auto-generated method stub
	
}




}

	


	


