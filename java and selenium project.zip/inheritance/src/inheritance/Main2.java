package inheritance;

public class Main2 {

	public static void main(String[] args) {
		
		overriding p;
		
		p = new UPI();
		p.pay();
		p = new Card();
		
		p.pay();

	}

}
