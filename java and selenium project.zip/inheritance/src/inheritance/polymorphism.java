package inheritance;

public class polymorphism {

	// overloading method 
	int add(int a ,int b) {
		return a + b;
		
}

	int add(int a, int b ,int c) {
		return a + b + c;
		
	}
	
}




