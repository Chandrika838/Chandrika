package inheritance;

public class Main3 {

	public static void main(String[] args) {
	
		// object 
		

        vehicle1 v;

        v = new Bike();
        v.start();

        v = new Motor();
        v.start();

	}

}
