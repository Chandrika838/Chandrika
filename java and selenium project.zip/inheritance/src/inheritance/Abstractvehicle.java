package inheritance;

abstract class Abstractvehicle { // for abstract class u need to write abstract only for the class to start with the body of program 

	abstract void start();// abstract method (no body) im just telling you to start but im not telling you how to start it it yet.
}

// child class 

class bike extends Abstractvehicle {
	
	void start() { // creating the method 
		
		System.out.println("Bike starts with the kick");
		
	}
}

