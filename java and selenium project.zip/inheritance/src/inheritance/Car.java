package inheritance;

public class Car extends Vehicle{

	String brand = "Toyota";
	
	
}
