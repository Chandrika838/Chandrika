package inheritance;

public class overriding {

	// RETURN THE method 
	
	void pay() { 
		System.out.println("Payment is done");
		
	}
}

class UPI extends overriding { // use for the overriding the method 
	
	void pay() {
		System.out.println("Paid using UPI");		
	}
}


class Card extends overriding { // use for the overiding the method 
	void pay() {
	System.out.println("Paid using Card");
}

}

