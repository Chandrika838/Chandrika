package inheritance;

public class Encapsulation {
	private double balance;
	
	// Constructor 
	
	Encapsulation(double balance){
		this.balance = balance; // refers to the class variable 
		
	}
// deposit method 
	
	public void deposit(double amount) {
		
		balance += amount ;
		
	System.out.println("Deposit :" + amount );
		
	}
	
	// withdraw method 
	
	public void withdraw(double amount) {
		if(amount <=balance) {
			
			balance = amount;
	System.out.println("Withdrawn :" + amount);
		} else {
			
	System.out.println("Insufficent balance");
	
		}
		
	}
	// getter method 
		
	public double getbalance() {
		return balance;
		
	}
	}

