/**
 * 
 */
/**
 * 
 */
module inheritance {
}