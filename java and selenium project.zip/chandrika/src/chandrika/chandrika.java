package chandrika;

public class chandrika {
	
	public static void main(String[]agrs) {

	for (int marks = 30; marks <= 100; marks += 10) { // so for loop has a three start ,condition ,change this where we use in java start from 30 marks <= 10 continue up till 100 or less marks += 10; increase marks by 10 each time 

	    if (marks < 40) {
	        continue;
	    }

	    System.out.println("Passed with marks: " + marks);
	}
	

}


}


