
package demo9classandobject;

public class dem09classandobject {

	public static void main(String[] args) {
		
		Car c1 = new Car();
		c1.model = "Shift";
		c1.price = 130000;
		
		c1.start();
		
	}
}

class Car {
	
	String model;
	int price; 
	
	void start() {
		
		System.out.println(model+" Started");
	}
			
			
}