/**
 * 
 */
/**
 * 
 */
module demo9classandobject {
}