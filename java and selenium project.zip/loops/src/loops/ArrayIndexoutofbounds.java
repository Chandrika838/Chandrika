package loops;

public class ArrayIndexoutofbounds {

	public static void main(String[] args) {
	
		
	}

}
