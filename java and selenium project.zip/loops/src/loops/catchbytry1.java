package loops;

public class catchbytry1 {

	public static void main(String[] args) {
		
		try {
			int a = 10;
			int b = 0;
			
			int result = a/b;
			
			System.out.println(result);
		} catch (ArithmeticException e) {
			
			System.out.println("Cannot divided by Zero");
		}
		
		System.out.println("End the program");
	}

}
