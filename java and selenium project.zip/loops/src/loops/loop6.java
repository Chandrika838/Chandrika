
package loops;

public class loop6 {

	public static void main(String[] args) {

		int count = 6;
		
		for(int i = 1; i <= 20; i++) {
			
			if(i % 3 == 0) {
				
				count ++;
				
			}
		}

		
		System.out.println("Print the number:" + count);
	}

}
