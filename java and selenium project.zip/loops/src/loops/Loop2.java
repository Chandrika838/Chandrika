package loops;

public class Loop2 {

	public static void main(String[] args) {
		
		int a = 7;
		
		for(int i = 1; i<=10; i++) {
			
			if(i% 2 ==0) {
		
		System.out.println(i);
	}

}

}
}