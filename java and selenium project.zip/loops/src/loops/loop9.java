package loops;

public class loop9 {

	public static void main(String[] args) {
		
		// string palindrome 
		
		String str = "Chandrika";
		String reverse = " ";
		
		// for string we need to use for loop in palindrome 
		
		
		for(int i = str.length() - 1; i>= 0; i--) {
			
			reverse = reverse +str.charAt(i);
			
		}
		if(str.equals(reverse)) {
			
			System.out.println("Panlindrome");
			
		} else {
			
			System.out.println("Not palindrome");
		}
	}

}
