package loops;

public class loop10login {

	public static void main(String[] args) {

		int attempts = 0;
		
		while(attempts < 3) {
		
		System.out.println("Trying login attempt:" +(attempts));
		
		attempts ++;
		
		System.out.println("System is locked");
		
	}

}
}
