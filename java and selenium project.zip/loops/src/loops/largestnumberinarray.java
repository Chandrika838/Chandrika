package loops;

public class largestnumberinarray {

	public static void main(String[] args) {
		
		int[] numbers = {23,56,78,90,45,67};
		
		int max = numbers[0];
		
		// for loop 
		
		for(int i = 1; i< numbers.length; i++) {
			
			if(numbers[i] > max) {
				
				max = numbers[i];
				
				
			}
		}
	
	System.out.println("Print the largest numbers:" + max);
	}
	
	

}
