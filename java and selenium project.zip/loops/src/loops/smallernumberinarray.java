package loops;

public class smallernumberinarray {

	public static void main(String[] args) {
	
		int[] num = {23,45,67,8,90,12};
		
		int mini = num[0];
		
		for(int i = 1; i < num.length; i++) {
			
			if(num[i] < mini) {
				
				mini = num[i];
				
				
				
			}
		
			System.out.println("Print the smallest numbers");
		}
		
		
		
	}

}
