package loops;

public class Nullpointer {

	public static void main(String[] args) {
		
		// null pointer example in java where we use it in most of the place in selenium 
		
		try {
			
			String name = "Chandrika ";
			
			System.out.println(name.length());
			
		} catch (NullPointerException e) {
			
			System.out.println("object is null");
			
			
		}
	}

}
