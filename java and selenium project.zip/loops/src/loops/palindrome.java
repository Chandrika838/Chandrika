package loops;

public class palindrome {

	public static void main(String[] args) {
	
		int num = 121;
		
		int original = num;
		
		int reverse = 0;
		
		// while loop 
		
		while(num != 0) {
			
			int digit = num % 10;
			reverse = reverse * 10 + digit;
			
			num = num / 10;
			
			
		}

		if (original == reverse) {
			
			System.out.println("palindrome");
			
		} else {
			
			System.out.println("NOT palindrome");
				
				
			}
			
			
		}
	}


