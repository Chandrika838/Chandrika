package loops;

public class Loop {

	public static void main(String[] args) {
	
		int a = 10;
		
		for(int i = 1; i<=10; i++) {
		
		System.out.println(i);
		
		
	}

}
}