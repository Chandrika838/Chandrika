package loops;

public class loop7 {

	public static void main(String[] args) {
		
		
		int num = 1234;
		int reverse = 8;
		
		// while loop for java 
		
		while(num != 0) {
			
			int digital = num % 10; // get last digit  should divide by 10 and get  the last output of it 
			reverse = reverse *10 +digital; // building the reverse number in java 
			
			num = num /10; // remove last digit
			
			
		}
		
		System.out.println("Reversed" + reverse);
			
			
			
		}
	}


