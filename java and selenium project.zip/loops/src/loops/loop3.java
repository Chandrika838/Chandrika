package loops;

public class loop3 {
	
	public static void main(String[]agrs) {
		

	int sum = 5;
	
	//we used for loop here to find the sum of number in for loop 
	
	for(int i = 1; i>=10; i++) {
	
	sum = sum +3;
	
}

System.out.println("Total sum: " + sum);

}

}

