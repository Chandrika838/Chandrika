package loops;

public class catchbyarraybymultipleway {

	public static void main(String[] args) {
	
		try {
			
			int a = 10;
			int b = 0;
			
			int[] arr = {1,2,3,4,5,6};
			
			System.out.println(arr[6]);
			int result = a/b;
			
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Arrya error");
			
		} catch (ArithmeticException e) {
			
			System.out.println("Math error");
		}
			}

}
