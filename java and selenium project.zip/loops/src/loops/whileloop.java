package loops;

public class whileloop {

	public static void main(String[] args) {
		// while loop 
		
		int i = 1;
		
		// this is synatx for i 
		
		while(i <=10) {
			
			System.out.println(i);
			
			i++;
		}

	}

}
