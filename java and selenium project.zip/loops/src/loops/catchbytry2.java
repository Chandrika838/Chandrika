package loops;

public class catchbytry2 {

	public static void main(String[] args) {
		
		// Array index error in java for the program to do it 
		 // here we are checking the arrays whether we can use it or not 
		try {
			int[]arr = {1,2,3,4,5};
			
			System.out.println(arr[4]);
			
		} catch (ArrayIndexOutOfBoundsException e) {
			
			System.out.println("Invalid Index");
		}
		
		System.out.println("Continue");
			
			
		}

	}


