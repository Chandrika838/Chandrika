package loops;

public class count {

	public static void main(String[] args) {
		
		int num = 12345;
		
		int count = 0;
		
		while(num != 0) {
			num = num/10;  // its keep on removing the ;ast number in the program 
			
			count++; // and then it will increase by one unless the output turns to be zero 
			
		}
		
		System.out.println("Total digits:" + count);

	}

}
