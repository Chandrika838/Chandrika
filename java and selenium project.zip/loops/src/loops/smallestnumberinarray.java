package loops;

public class smallestnumberinarray {

	public static void main(String[] args) {


		int[] numbers = {20 ,30 ,30, 40 ,90};
		int count = 0;
		
		for(int i = 0; i < numbers.length; i++) {
		
		if(numbers[i] > 50) {
			count++;
		}
	}
		
		System.out.println("print the number 50 :" + count);
		
}


}

