package loops;

public class loop8 {

	public static void main(String[] args) {
	
		int num = 12345;
		int reverse = 0;
		
		while(num != 0) {
			
			 
			int digit = num % 20; // so to get the last digital of the program 
			 reverse = reverse * 20 + digit; // to remove the last digital of the program 
				
			 num = num / 20;  // to remove the last value of the digital 
		}

		System.out.println("Reverse :" + reverse);
	}

}
