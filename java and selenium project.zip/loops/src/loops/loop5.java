package loops;

public class loop5 {

	public static void main(String[] args) {
	
		// loop for automation in java 
		
		
		String[] users = {"admin","test","guest"};
		for (int i = 0; i <  users.length; i++) {
			
			System.out.println("users:"+users[i]);
			
			
		}
		

	}

}
