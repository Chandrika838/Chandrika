package demolength;

public class demolength {

	public static void main(String[] args) {
		
		String a = "Chandrika is a good gal and sweet gal";

		System.out.println(a.lastIndexOf("gal"));
	
	String b = "chandrika is a sweet gal";
	
	System.out.println(a.lastIndexOf('a')); 
	System.out.println(b.lastIndexOf(5, 'n'));
	System.out.println(b.lastIndexOf('r', 5));
	}
	
	

}
