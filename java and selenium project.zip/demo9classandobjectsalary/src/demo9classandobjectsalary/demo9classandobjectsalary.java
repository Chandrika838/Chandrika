package demo9classandobjectsalary;

public class demo9classandobjectsalary {

	public static void main(String[] args) {
		
		Employee e1 = new Employee();
		
		e1. name = "chandrika";
		e1. Salary = 40000;
		
		e1.display();
	
	
	}

}


class Employee {
	
	String name; //calling the method 
	int Salary;
	
	void display () {
		System.out.println(name +"Salary is :" + Salary);
	}
}
