/**
 * 
 */
/**
 * 
 */
module demo9classandobjectsalary {
}