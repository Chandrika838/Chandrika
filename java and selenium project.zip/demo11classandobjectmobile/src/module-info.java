/**
 * 
 */
/**
 * 
 */
module demo11classandobjectmobile {
}