package demo11classandobjectmobile;

public class demo11classandobjectmobile {

	public static void main(String[] args) {
		
		
		Mobile m1 = new Mobile ();
		
		m1. brand = "Samsung";
		m1. price = 300000;
		
		m1. display ();
		

	}

}

class Mobile {
	
	String brand;
	int price;
	
	void display () {
	System.out.println("brand :" + brand);
	System.out.println("price :" + price);
	
}
}
