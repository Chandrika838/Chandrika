package demo26switchstatement;

import java.util.Scanner;
public class demostatement {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Enter the marks:");
		
		int marks = sc.nextInt();
		
		switch(marks/100) {
		
		case 1 :
			
			System.out.println("Grade A");
			
			break;
			
		case 2:
			
			System.out.println("Grade B");
			break;
			
		case 3:
			System.out.println("Grade C");
			break;
		
		case 4:
			System.out.println("Grade D");
			
			default:
				
			System.out.println("fail");
			
			
		
		
		
		}
	}

}
