/**
 * 
 */
/**
 * 
 */
module demo26switchstatement {
}