package demo5; // for loop in single dimension array in java 

public class demo5 {

	public static void main(String[]agrs) {
		
		int[] a = {1,2,3,4,5,6,7,66,556,4};
		
		System.out.println("the size of array: " +a. length); // to check the length of array in single dimension  
	
		// for loop single dimenision 
		
		for (int i = 0; i<a.length; i++) { // current value is 0 
			
			System.out.println(a[i]);
		}
	}
	

	
}
