package demo;

public class demo {
	
	
        public static void main(String[]agrs) { // you should use the main method only once there should be two method in class 
	   
      Car maruthi = new Car (); // object  will create new for car class // object creation stmt 
        
      Car suzuki = new Car ();
      Car benz = new Car ();
      
      maruthi.carmodel = "Swift VDI";
      maruthi.color = "Red";
      maruthi.cost = 1200000;
      
      maruthi.starCar();
      maruthi.stopCar();
      maruthi.carDetails(); // call method 
      
        // in case if u want to access the new class u need to give a variable name in the main class 
        }
	}


class Car { // if u want to use the second class u should not use public in the second class
	String carmodel;
	int cost;
	String color;
	
	
	public void starCar() {  // method 
		
		System.out.println(carmodel + " started");
	}
	
	public void stopCar() { // template 
		
		System.out.println(carmodel + "stopped");
		
		
	}
	
		
	public void carDetails() { // cal the car 
		
		System.out.println("the model of the car is :" 
				+carmodel);
		
		System.out.println("the cost of the car is :" + cost);
		System.out.println("the color of the car is :" +color);
	}
}