package java;

public class java {

	static int a = 5, b = 6; //golbal variable  but in  class // static can access static method only 
	public static void main(String[]agrs) { // this is main method in java program 
		
	
     System.out.println(" the sum of number :" +(a+b));
	
     methodA();
     
	}

	
	
	
	public static void methodA() {
		
		
	}
  }
