package seleniumpackage;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Openwebiste {

	public static void main(String[] args) throws InterruptedException {
	//implict wait // will tell u wait 5 sec 
		
		
   WebDriver driver = new ChromeDriver();
   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5)); // set implicit wait to 5 seconds
   String password = getPassword(driver); // obtain temporary password from the page
   driver.get("https://rahulshettyacademy.com/locatorspractice/");
	driver.findElement(By.id("inputUsername")).sendKeys("Chandrika");// in case if u want to add in the web page u need to u send.keys in selenium 
	driver.findElement(By.name("inputPassword")).sendKeys("password");  // this we used because we gave incorrect passowrd here so we got that message 
	driver.findElement(By.className("signInBtn")).click();
	System.out.println(driver.findElement(By.cssSelector("p.error")).getText());

	driver.findElement(By.linkText("Forgot your password?")).click();

	Thread.sleep(1000);//

	driver.findElement(By.xpath("//input[@placeholder='Name']")).sendKeys("John");

	driver.findElement(By.cssSelector("input[placeholder='Email']")).sendKeys("john@rsa.com");

	driver.findElement(By.xpath("//input[@type='text'][2]")).clear();

	driver.findElement(By.cssSelector("input[type='text']:nth-child(3)")).sendKeys("john@gmail.com");

	driver.findElement(By.xpath("//form/input[3]")).sendKeys("9864353253");

	driver.findElement(By.cssSelector(".reset-pwd-btn")).click();

	System.out.println(driver.findElement(By.cssSelector("form p")).getText());

	driver.findElement(By.xpath("//div[@class='forgot-pwd-btn-conainer']/button[1]")).click();

	Thread.sleep(1000);

	driver.findElement(By.cssSelector("#inputUsername")).sendKeys("rahul");

	driver.findElement(By.cssSelector("input[type*='pass']")).sendKeys("rahulshettyacademy");

	driver.findElement(By.id("chkboxOne")).click();

	driver.findElement(By.xpath("//button[contains(@class,'submit')]")).click();

	driver.findElement(By.className("logout-btn")).click();
	driver.close();

	}

	// im creating the method 
	
	public  static  String getPassword(WebDriver driver) throws InterruptedException { // accept WebDriver so method is more general
		
		driver.get("https://rahulshettyacademy.com/locatorspractice/");	
	
		driver.findElement(By.linkText("Forgot your password?")).click();
	
		Thread.sleep(1000);//
		driver.findElement(By.cssSelector(".reset-pwd-btn")).click();

		String passwordText = driver.findElement(By.cssSelector("form p")).getText();
		// example passwordText: "Please use temporary password 'rahulshettyacademy' to login." 
		String[] parts = passwordText.split("'");
		if (parts.length >= 2) {
			return parts[1].trim(); // the password is between single quotes
		}
		return "";
	
	
	// 0th index - please use temporary password 
	// 1st index - rahulshettyacademy to login.
	
	}
		
		
		
	
}
	
	

