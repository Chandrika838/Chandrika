package demo16;

public class democlass {

	public static void main(String[] args) {
		
	 
  // Employee 1 
		
		Employee e1 = new Employee();
		
       e1.name = "Chandrika";
       e1.ID = 102;
       e1.basicSalary = 30000;
       
       // Employee 2 
       
       
       Employee e2 = new Employee();
       
       e2.name = "Parimala";
       e2.ID = 202;
       e2.basicSalary = 40000;
       
       
       // Display 
       
       e1.displaydetails();
       e2.displaydetails();
       
       
	}

}

class Employee {
	
	String name;
	int ID ;
	double basicSalary;
	
	// calculate the salary 
	
	double calculateSalary() {
		
		double hra = 0.2 * basicSalary;
		
		double da = 0.1 * basicSalary;
		
		double voucher;
		
		if (basicSalary > 30000) {
			
		} else {
			voucher = 2000;
			
		}
		
		double totalSalary = basicSalary + hra + da ;
		 return totalSalary ;
	}

	void displaydetails() {
		
		System.out.println("Eomployee name :" + name);
		System.out.println("Employee ID :" + ID);
		System.out.println("Employee Salary:" + basicSalary);
		System.out.println("Total Salary :" + calculateSalary());
		System.out.println("-----------------------");
		
		
	}
	
}
	
