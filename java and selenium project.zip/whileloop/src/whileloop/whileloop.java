package whileloop;

import java.util.Scanner;
public class whileloop {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String Password = "";
		int attempts = 0;
		
		while (! Password.equals("1234") && attempts <3){
			
			System.out.println("Enter Password:");
			
			Password = sc.nextLine();
			
		}
		 if (!Password.equals("1234")) {
		 
		 System.out.println("Enter Wrong Password");
			
		 }
		 
		 if (Password.equals("1234")) {
			 System.out.println("Login successful");
		 }
		
		 else {
			 if (Password.equals("1234"));
			 System.out.println("Account is locked");
			 
			 sc.close ();
		 }
	}

}
