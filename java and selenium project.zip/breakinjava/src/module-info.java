/**
 * 
 */
/**
 * 
 */
module breakinjava {
}