package breakinjava;

public class breakinjava {

	public static void main(String[] args) {
		
		for (int i = 0; i<10;i ++) {
			
			if (i %2==1) { // to get the even number in the program we use % symbol for ex 2 % 0 is 2 so we will get the even number here 
			
			continue ;
		}
		
		System.out.println(i);
		}
	}
	 
}




