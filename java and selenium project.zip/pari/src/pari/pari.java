package pari;

public class pari {
	
	public static void main (String[]agrs) {
  
	methodA();
		System.out.println(methodA());
	
	}
	


public static int methodA() { // calls this method 
	
	return 5; // result 
}
}