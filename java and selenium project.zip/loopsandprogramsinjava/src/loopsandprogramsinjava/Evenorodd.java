package loopsandprogramsinjava;

public class Evenorodd {

	public static void main(String[] args) {
	
		int num = 7;
		
		if (num %  3== 0) {
			
			System.out.println("Print even");
		}else {
			
			System.out.println("Print odd");
		}

	}

}
