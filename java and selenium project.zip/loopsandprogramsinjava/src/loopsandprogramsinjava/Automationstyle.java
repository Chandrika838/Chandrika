package loopsandprogramsinjava;

public class Automationstyle {

	public static void main(String[] args) {
		
		String actualTest = "Welcome";
		
		String expectedTest = "Welcome";
		
		
		if(actualTest.equals(expectedTest)) {
			
			System.out.println("Test Passed");
			
		} else {
			
			System.out.println("Test Failed");
			
			
		}
	}

}
