package loopsandprogramsinjava;

public class Multiplecondtions {

	public static void main(String[] args) {
	
		int marks = 85;
		
	// here we will use the if else statement in this program 
		
		if(marks >= 90) {
			
			System.out.println("Print A Grade");
		
		} else if (marks >=75) {
			
			System.out.println("Print B Grade");
			
		} else if (marks >=40) {
			
			System.out.println("Print C Grade");
			
		} else { 
			System.out.println("Fail");
			
			
			
			
			
			
		}
	}

}
