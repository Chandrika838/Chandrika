package loopsandprogramsinjava;

public class ifelse {

	public static void main(String[] args) {
	
		// check username and password 
		
		String Username = "admin";
		String Password = "1234";
		
		// now we need to use the if else statement 
		
		if(Username.equals("admin") && Password.equals("123")){
			
			System.out.println("Login successful");
			
		}else {
			
			System.out.println("Login is not successful");
		}
	}

}
