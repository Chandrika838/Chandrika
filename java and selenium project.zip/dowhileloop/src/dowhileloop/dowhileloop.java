package dowhileloop;

import java.util.Scanner;

public class dowhileloop {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String USername = "";
		String Password = "";
		
		while (!(USername.equals("Admini") && Password.equals("1234"))) {
			
		}
			
			System.out.println("Enter User Name");
			
			USername = sc.nextLine();
			System.out.println("Enter Password");
			
			Password = sc.nextLine();
			
			if (!USername.equals("USername") && Password.equals("Password")) {
			System.out.println("Invalid Successful, Try again\n");
			
			
			}
			
		System.out.println("Login Successful");
			
			sc. close ();
				
			}
			
	}

			
		

	


