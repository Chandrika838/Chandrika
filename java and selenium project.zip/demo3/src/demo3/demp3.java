package demo3;

public class demp3 {
	
	public static void main(String[]agrs) {
		
		Mobile m1 = new Mobile();
		m1. brand = "Samsung"; 
		m1. price = 16000;
		m1. city = "Bangalore";
		
		m1. show ();
		
	}

}


class Mobile {
	
	String brand ;
	int price;
	String city;
	
	void show() {
		System.out.println("Brand :" + brand);
		System.out.println("Price :" + price);
		
	
	
}
}
	
