/**
 * 
 */
/**
 * 
 */
module inhertiance {
}