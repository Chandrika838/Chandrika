package inhertiance;

public class multipleA {

	int y ;
	
	public void methody() {
		
		
	}
}
