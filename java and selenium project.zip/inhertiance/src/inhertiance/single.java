package inhertiance;

public class single {

	int x ;
	int y;
	
	public void methodx() {
		
	}
	
	public void methody() {
		
		
	}
 }
