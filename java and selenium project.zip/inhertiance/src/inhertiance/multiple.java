package inhertiance;

public class multiple {
	
	int x ;
	
	public void methoda() {

	}
}
