package inhertiance;

public class multiB extends multi1  {


}
