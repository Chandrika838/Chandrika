package inhertiance;

public class hybird2 extends hybrid{

}
