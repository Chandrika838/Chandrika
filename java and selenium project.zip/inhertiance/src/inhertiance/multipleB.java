package inhertiance;

public class multipleB extends multipleA {
	
	

}
