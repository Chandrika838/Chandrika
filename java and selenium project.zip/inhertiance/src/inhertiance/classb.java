package inhertiance;

public class classb extends single {
	
	

	
}
