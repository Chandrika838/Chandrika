package inhertiance;

public class hybrid {

	int x;
	
	public void methodx() {
		
		
	}
}
