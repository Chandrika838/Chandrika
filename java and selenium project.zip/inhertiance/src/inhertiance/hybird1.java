package inhertiance;

public class hybird1  extends hybrid {
	
	
	int y;
	
	public void methody() {
		
		
	}

}
