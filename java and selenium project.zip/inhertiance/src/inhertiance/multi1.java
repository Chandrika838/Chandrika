package inhertiance;

public class multi1 {
	
	int x;
	int y;
	
	public void methodx() {
		
		
	}

	public void methody() {
		
	}
}
