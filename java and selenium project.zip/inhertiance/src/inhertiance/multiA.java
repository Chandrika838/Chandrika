package inhertiance;

public class multiA  extends multiB{

	int z;
	
	public void methodz() {
		
		
	}
}
