package inhertiance;

public class hybird3 extends hybrid{

}
