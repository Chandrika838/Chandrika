package Main;

import Student.Student;
import Teacher.Teacher;

public class Main {

	public static void main(String[] args) {
	
		Student s = new Student();
		Teacher t = new Teacher();
		
		s.show();
		t.show();
		

	}

}
