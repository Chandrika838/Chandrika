package Student;

public class Student {

	public void show() {
		
		System.out.println("Student class");
	}
}
