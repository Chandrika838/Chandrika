package Teacher;

public class Teacher {

	public void show() {
		
		System.out.println("Teacher Class");
	

	}

}
