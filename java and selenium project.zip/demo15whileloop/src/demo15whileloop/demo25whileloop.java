package demo15whileloop;

import java.util.Scanner;
public class demo25whileloop {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner (System.in);
	
		int Correctpin = 1234;
		
		int attempts = 0;
		
		while (attempts < 3) {
			
			System.out.println(" Enter the pin ");
			
			int pin = sc.nextInt();
			
		if (pin == Correctpin) {
			
			System.out.println("Access is granted");
			
			break;
			
		}else {
			
			System.out.println("Wrong pin");
		}
			attempts++;
			
		}
		
         if (attempts == 3) {
        	 
        	 System.out.println("Card blocked");
         }
	}

}
