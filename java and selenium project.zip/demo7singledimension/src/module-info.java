/**
 * 
 */
/**
 * 
 */
module demo7foreach {
}