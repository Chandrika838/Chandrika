package demo7foreach;

public class demo6foreach {

	
	 public static void main (String[] agrs) {
		 
		 int [] a = {2,3,4,5,6,7,8,9,0,1,1,2,1,31,4,15,1,6,17};
		 
		 System.out.println("the size of arrays is : " + a.length);
		 
		 for(int arrays : a) {
			 
			 System.out.println(arrays);
		 }
	 }
}
