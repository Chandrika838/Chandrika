package mypracticesession;

public class Bankmain {

	public static void main(String[] args) {
	
		Bank obj = new Bank();
		obj.deposit(50000);
		obj.checkBalance();
		obj.withdraw(5999);
		
	}

}
