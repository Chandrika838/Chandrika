package mypracticesession;

public class Bank {

	int balance = 5000;
	
	void deposit(int amount){ // method 
		balance =balance +amount;
		System.out.println("Deposit:" + amount);	
	}
	
	void withdraw(int amount) {
		
		if(amount <= balance) {
			
			System.out.println("Withdrwan: "+ amount);
		}else {
			
			System.out.println("Insufficent balance");
		}

	}


 void checkBalance() {
	 
	 System.out.println("current Balance:" + balance);
	 
 }

}




