package pratice;

public class pratice {

	public static void main(String[] args) {
		
	// ending the mid value of 1 and 11
		
		int i = 1 , j = 11;
		
		while(++ i < -- j) {
			
			System.out.println("the mid value of 1 and 11 is "+"");
		}
   
   }
	}

