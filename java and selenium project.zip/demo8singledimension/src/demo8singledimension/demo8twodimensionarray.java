package demo8singledimension;

public class demo8twodimensionarray {

	public static void main(String[] args) {
	
		// two dimension array 
		
		
		int [][] a = {{ 6,6,3},{2,3,4}};
		
		
		System.out.println("the arrays is :" +a.length);
		

	}

}
