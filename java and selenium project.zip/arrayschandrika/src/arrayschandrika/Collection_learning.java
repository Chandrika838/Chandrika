package arrayschandrika;

public class Collection_learning {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
