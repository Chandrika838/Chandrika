package demo2;

public class demo2 { // main class in java 
	
	public static void main(String[]agrs) {
		
		Student s1 = new  Student(); // object // student 
		
		s1. name = "Chandrika";
		s1.age = 28;
		s1.address = "kalyan nagar";
		
		s1. display();
	}
}


class Student {
	
	String name;
	
	int age;
	String address;
	
	void display () {
		
		System.out.println("Name:" + name);
		System.out.println("Age :" + age);
		System.out.println("Address :" + address);
	}
}