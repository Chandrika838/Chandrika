package demo30;

public interface interfaceone {

	//body 
	
	public void methodOne();
	
	
}
