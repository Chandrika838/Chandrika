/**
 * 
 */
/**
 * 
 */
module demo30 {
}