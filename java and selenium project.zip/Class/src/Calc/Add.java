package Calc;

public class Add {

	public void sum() {
		
		System.out.println(10+20);
		
		
	}
	
}
