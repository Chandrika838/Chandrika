package Clac1;

import Calc.Add;

public class Main {

	public static void main(String[] args) {
	
		Add a = new Add();
		
		a.sum();
		

	}

}
