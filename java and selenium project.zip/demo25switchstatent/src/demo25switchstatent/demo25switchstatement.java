package demo25switchstatent;

import java.util.Scanner;

public class demo25switchstatement {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int balance = 5000;
		
		System.out.println("1.Deposit");
		System.out.println("2 Withdrwa");
		System.out.println("3 Check Balance");
		
		int choice = sc.nextInt();
		
		switch (choice) {
		
		case 1:
			System.out.println("Enter amount:");
			int deposit = sc.nextInt();
			balance +=deposit;
			System.out.println("Balance = "+ balance);
			
			break;
			
		case 2:
			
			System.out.println("Enter the amount:");
			int withdrwa = sc.nextInt();
			balance +=withdrwa;
			System.out.println("Withdrwa =" + withdrwa);
			break;
			
		case 3:
			
			System.out.println("Balance = "+ balance);
			break;
			
			default:
				System.out.println("Invalid operator");
				
		
			
			
			
		
			
		}
		

	}

}
