package pracitingpurpose;

public class ClassA {

	protected int a;
	
	protected void methodA() {
		
	}
	
	// we can use protected for variable , method , constructor but we can't use it for class when we use it will show the complier error in java 
	
	protected ClassA() {
		
	}
}
