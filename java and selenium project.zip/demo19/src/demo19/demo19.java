package demo19;

public class demo19 {

	public static void main(String[] args) {
		
		Employee e1 = new Employee ();
		
		e1.name = "Chandrika";
		e1.Salary = 30000;
		
		e1.display();
		
		
       
	}

}


class Employee {
	
	String name;
	int Salary ;
	
	void display() {
		
		System.out.println("Name :" +name +  "Salary is :" +  Salary);
	}
	
	
}