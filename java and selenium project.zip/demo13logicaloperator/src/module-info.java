/**
 * 
 */
/**
 * 
 */
module demo13logicaloperator {
}