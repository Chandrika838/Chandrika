package demo13logicaloperator;

import java.util.Scanner;
public class demo13logicaloperator {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		String Correctusername = "Admin";
		String Correctpassword = "1234";
		
		System.out.println("Enter the Username");
		String username = sc.nextLine();
		
		System.out.println("Enter the  Password");
		String Password = sc.nextLine();
		
		// And condtion 
		
		if(username.equals(Correctusername)&& Password.equals(Correctpassword))  
		
          System.out.println("logical is successful");
          
          
         // User Name Details
          
          int age = 28;
          boolean ID = true;
          boolean Notbanned = true;
          
          // Use and and or condition 
          
          
          if (age >=18 && ID && !Notbanned) {
        	  
        	  System.out.println("Access is granted");
        	  
          } else {
        	  
        	  System.out.println("Access is successful");
        	  
          } 
          

		
		System.out.println("Invalid username or Password ");
		
	}
        	
        	  
          }
	


