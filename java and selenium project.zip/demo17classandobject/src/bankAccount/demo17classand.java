
      package bankAccount;

class Employee {

    String name;
    int id;
    double Salary;

    double calculateSalary() {
        double hra = 0.2 * Salary;
        double da = 0.1 * Salary;
        double totalSalary = Salary + hra + da;
        return totalSalary;
    }

    void displaydetails() {
        System.out.println("Employee Name: " + name);
        System.out.println("Employee ID: " + id);
        System.out.println("Basic Salary: " + Salary);
        System.out.println("Total Salary: " + calculateSalary());
        System.out.println("-----------------------");
    }
}

public class demo17classand {

    public static void main(String[] args) {

        // Object 1
        Employee e1 = new Employee();
        e1.name = "Chandrika";
        e1.id = 102;
        e1.Salary = 20000;

        // Object 2
        Employee e2 = new Employee();
        e2.name = "Parimala";
        e2.id = 203;
        e2.Salary = 30000;

        // Display
        e1.displaydetails();
        e2.displaydetails();
    }
}
