/**
 * 
 */
/**
 * 
 */
module demo17classandobject {
}