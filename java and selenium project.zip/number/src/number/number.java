package number;

public class number {

	static String check(int num) {
		
		if (num% 10 == 0) {
			
			return "Even";
			
		}
	     
		return "odd";
}

public static void main (String [] agrs) {
	
	String number = check(7); // method call check the even or odd nmer
	
	System.out.println(number);
}
}