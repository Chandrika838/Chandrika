package demo6;

public class demo6 {
 
	public static void main(String[]agrs) {
		
		int [] a = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
		
		System.out.println("the size of an array is :" + a.length);
		
		for (int i = 0; i<a.length; i ++) {
		
		System.out.println(a[i]);
	}
}

}