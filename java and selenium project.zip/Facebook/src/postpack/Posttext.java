package postpack;

import loginpack.*;

public class Posttext {

	
	String text;
	public void postHere() {
		
		// login
		
	login login = new login();// just addedd import to this 
	login.username = "Chandrika";
	login.passowrd = "password ";
	
	
	login.loginHere();
	
	System.out.println("Posting is successfull");
	
	
	logout logout= new logout();
	
		
		// logout
		// post 
		
	}
}
