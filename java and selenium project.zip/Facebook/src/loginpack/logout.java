package loginpack;

public class logout {

	int sessiontime; // variable
	
	public void logoutHere() {
		// Method 
		
		login login = new login();
		
		login.username = "Chandrika";
		login.passowrd = "Password";
		
		login.loginHere();        // if u want to access the prefere of different variable and object we need to use the login.login 
		
		System.out.println("Logout Successful");
		
	}
}
