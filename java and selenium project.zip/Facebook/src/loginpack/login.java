package loginpack;

public class login {

public	String username;  // if u doesn't provide the public specify u can't access to the public and u can't create in the another class and if dont provide it will default 
public 	String passowrd;
	
	public void loginHere() { // method 
		
		System.out.println("Login Successfull");
	}
}
