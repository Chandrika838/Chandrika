package demo16dowhileloop;

import java.util.Scanner;
public class demo16whileloop {

	public static void main(String[] args) {
	
		
		Scanner sc = new Scanner (System.in);
		
		int guess ;
		
		do {
			
			System.out.println("Guess the number :");
			
			guess = sc.nextInt();
			
		} while (guess != 10);
		System.out.println("Correct Number");
		}
	}
	

	