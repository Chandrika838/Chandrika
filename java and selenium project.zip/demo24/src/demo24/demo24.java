package demo24;
import java.util.Scanner;
public class demo24 {

	public static void main(String[] args) {


		Scanner sc = new Scanner (System.in);
		
		System.out.println("1.pizza\n2.burger\n3. Sandwich");
		System.out.println("Enter your choice");
		
		int choice = sc.nextInt();
		
		switch(choice) {
		
		case 1:
			System.out.println("burger = 200");
			break;
			
		case 2:
			System.out.println("pizza = 300");
			break;
			
		case 3:
			System.out.println("Sandwich = 250");
			
		default:
			
			System.out.println("Invalid option");
				
		}
	

	}

}
