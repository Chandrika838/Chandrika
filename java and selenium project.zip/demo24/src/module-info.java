/**
 * 
 */
/**
 * 
 */
module demo24 {
}