package chinnu;

public class chinnu {

	public static void main(String[] args) {
	
		System.out.println("Inside main method");
		
		methodB();// No need to pass anything 
		
		methodA(9); // we need to use the number to pass the value in the method A for the paramenter to call for 
	}
	
	
	public static void methodA(int a) { // String paramterized method 
	
		System.out.println("Inside the parameter value:"+ a);
		
	}
	
	public static void methodB() {
		
	}
}
