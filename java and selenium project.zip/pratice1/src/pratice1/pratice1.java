package pratice1;

public class pratice1 {
	
	public static void main (String[]agrs) {
		 //array index out of bound 

	int[] a = new int[3];
	
	a[0] = 5;
	a[1] = 7;
	a[2] = 6;
}

}
