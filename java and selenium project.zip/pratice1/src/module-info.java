/**
 * 
 */
/**
 * 
 */
module pratice1 {
}