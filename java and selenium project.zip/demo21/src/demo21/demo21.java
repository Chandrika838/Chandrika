package demo21;

public class demo21 {

	public static void main(String[] args) {
	 
		Mobile m1 = new Mobile();
		
		m1.name = "Samsung";
		m1.RAM = 7;
		m1.Price = 24000;
		
		m1.display();
		
		
		

	}

}

class Mobile {
	
	String name;
	int RAM;
	int Price ;
	
	void display() {
		
		System.out.println("Mobile name is:" + name  + RAM + Price);
	}
}