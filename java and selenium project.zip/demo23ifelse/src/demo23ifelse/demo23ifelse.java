package demo23ifelse;

public class demo23ifelse {

	public static void main(String[] args) {
	 // positive negative or zero
		
		int num = 5;
		
		if (num > 15) {
			
			System.out.println("Print postive");
			
		}else if (num < 0) {
			
			System.out.println("print  negative");
			
		}else {
			
			
			System.out.println("Print Zero ");
			
		}

	}

}
