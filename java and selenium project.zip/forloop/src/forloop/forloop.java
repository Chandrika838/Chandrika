package forloop;

public class forloop {

	public static void main(String[] args) {
		 int i = 0;
		 do {
			 
			 System.out.println("chandrika"+ i); // incase if you want to print i in while loop for the print 
			 
			 i ++;
			 
		  
		 }while(i<5);
	}

}
