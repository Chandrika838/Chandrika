package demospilt;

public class dempsplit {
	
	public static void main(String[] agrs) {
		
		String a = "Arun";
		String b = "  ";
		String c = "Motoori";
		
		System.out.println(a.concat(b).concat(c));
		
	}

}
