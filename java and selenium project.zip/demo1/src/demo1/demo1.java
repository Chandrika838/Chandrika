package demo1;

public class demo1 {
	
	public static void main (String []agrs) {

	// declare ,Create , arryas and access arryas 
	
	int [] a = new int[3]; // declaration of dimension arrays 
	
	a[0] = 5; // index value of arrays in java where we need to store value in them 
	a[1] = 3;
	a[2] = 9;
	
	// Access or retrerive the asseigned value 
	
	System.out.println(a [0]);
	System.out.println(a[1]);
	System.out.println(a[2]);
	
	
	}

}

	
	
