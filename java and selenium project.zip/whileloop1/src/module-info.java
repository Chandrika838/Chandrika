/**
 * 
 */
/**
 * 
 */
module whileloop1 {
}