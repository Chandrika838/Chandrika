package whileloop1;

import java.util.Scanner;
public class whileloop1 {
	
	public static void main(String [] agrs) {

		Scanner sc = new Scanner(System.in);
		
		String Username = "";
		String Password = "";
		
		while (!Username.equals(Username) && Password.equals(Password)) {
			
			System.out.println("Enter username");
			
			Username = sc.nextLine();
			
			System.out.println("Enter Password");
			
		Password = sc.nextLine();
		
		if (!(Username.equals(Username) && Password.equals(Password))) {
			System.out.println("Invalid password try again");
			
		}
		}
		
		System.out.println("Login is Successful");
		
		sc.close();
		
	}
}
