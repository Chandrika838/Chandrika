package demoooo;

public class demoooo { // user name 

	public static void main(String[] args) {
	
	// primtive data type in java  
		
		byte a = 1;
		short b = 5;
		int c = 9;
		long d = 99L;
		float e =1.234f;
		double f = 3.566;
		char g= 'c';
		boolean h = true;
		
		String.valueOf(a);
		// converting this into string 
	String bv =	String.valueOf(b);
	String.valueOf(c);
	String.valueOf(d);
	String.valueOf(e);
	String.valueOf(f);
	String.valueOf(g);
	String.valueOf(h);
	
	Byte i = 3;
	short j = 4;
	Integer k = 6;
	Long l = 12L;
	Float m = 1.234F;
	Double n = 3.567;
	Character o = 's';
	Boolean p = false;
	
	
	String iv = String.valueOf(j);
}
}
