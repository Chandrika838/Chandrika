package demo29;

public class Classone {

	// no object can be create  if u want to create a object first u need to create for the child class 
	
	Classone one = new Classone();
	
	
}
