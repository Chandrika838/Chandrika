package demo29;

public class ClassTwo extends demo29{  // class two has a abstract method in class one we need to create a child class where we need to create a class for this 

	@Override
	public void methodOne() {
	
		System.out.println("Inside methodOne of child class");
		// why we use the abstraction class when we don't to implememt in parent class  u want to impleement in child class for example u want to implement few thingand few thing later such kindof approach we use abstract class 
	}

}
