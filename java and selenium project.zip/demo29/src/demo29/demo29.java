package demo29;

public abstract class demo29 {
 public abstract void methodOne();
 // body of the program 
 
 public void methodTwo() {
	 
	 System.out.println("Inside methodTwo");
 }
}
