package demo15dowhileloop;

import java.util.Scanner;
public class demo15dowhileloop {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		int balance = 30000;
		int choice;
		
		do {
			System.out.println("1. Check Balance");
			System.out.println("2. Deposit");
			System.out.println("3. Exit");
			
			System.out.println("Enter choice");
			
			choice = sc.nextInt();
			
			switch (choice) {
			
			case 1:
				
				System.out.println("Balance" + balance);
				
				break;
				
			case 2 : 
				
			 case 3:
                 System.out.println("Enter amount:");
                 int amount = sc.nextInt();
                 balance += amount;
                 System.out.println("Updated Balance: " + balance);
                 break;

             case 4:
                 System.out.println("Thank you!");
                 break;

             default:
                 System.out.println("Invalid choice");
         }

     } while(choice != 3);
 
}
			
			}
		
	

	


