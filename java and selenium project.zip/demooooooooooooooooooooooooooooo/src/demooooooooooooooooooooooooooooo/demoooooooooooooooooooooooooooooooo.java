package demooooooooooooooooooooooooooooo;

import java.util.Scanner;

public class demoooooooooooooooooooooooooooooooo {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the first number");
		int a = sc.nextInt();
		
		System.out.println("Enter the Second Number");
		int b = sc.nextInt();
		
		System.out.println("Enter the third number");
		int c = sc.nextInt();
		
		System.out.println("Enter the operator (+,-,*,/)");
		
		char choice = sc.next().charAt(0);
		
		switch(choice) {
		
		case '+':
			System.out.println("Result = "  +(a+b));
			
			break;
			
		case '-':
			
			System.out.println("Result = " + (a-b));
			break;
			
		case '*':
			
			System.out.println("Result =" +(a* b));
			break;
			
		case '/':
			
			System.out.println("Result =" +(a/b));
		
			default:
				
				System.out.println("Invalid operator");
		}
			
			
		}
		
	}
		
	