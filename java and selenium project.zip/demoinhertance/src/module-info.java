/**
 * 
 */
/**
 * 
 */
module demoinhertance {
}