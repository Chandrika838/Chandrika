package demoinhertance;

public class benz  extends demo { // instead of writing the same class again and again we can use inhertance in java 
	
	String moonRoofsColor;
	
	public void autoGearMode() {
		
		System.out.println("Benz auto gear on");
		
	}

	
}
