package demoinhertance;

public class Car {
	
	public static void main(String[]agrs) {
		
		benz b = new benz();
		
	

		}

}
