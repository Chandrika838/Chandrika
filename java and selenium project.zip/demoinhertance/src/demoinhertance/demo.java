package demoinhertance;

public class demo {

	int cost;
	String color;
	String model;
	int speed;
	
	public void startCar() {
		
		System.out.println(model+" car Started");
		
	}
	
	public void stopCar() {
		
		System.out.println(model+ "car Stopped");
	}
}



	
	
	
