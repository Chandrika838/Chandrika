package whileloop2;

import java.util.Scanner;
public class whileloop {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String Username ="";
		String Password ="";
		
		while(!Username.equals(Username)&& Password.equals(Password)){
			
			System.out.println("enter Username");
			
			Username = sc .nextLine();
			
			System.out.println("Enter Password");
			
			Password = sc.nextLine();
			
			if (!Username.equals(Username) && Password.equals(Password)){
				
				System.out.println("Invalid Login! Try Againn\n");
				
				System.out.println("Login is Successful");
				
				sc.close();
			}
				
		}
	
		

	}

}
