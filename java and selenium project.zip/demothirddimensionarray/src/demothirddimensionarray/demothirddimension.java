package demothirddimensionarray;

public class demothirddimension {

	public static void main(String[] args) {

		int [][][] a = {{{ 1,2,3,4} ,{1,2,3,4,5},{5,7,8,9,0}},{{4,5,6,7,8},{3,4,5,6,7},{6,7,8,9,0}}};
		
		System.out.println("the size of an array is :" + a[1].length);

		
		for (int i = 0; i<a.length; i++) {
		
		for (int j =0; j<a[0].length; j++) {
		
		for (int q = 0; q<a[1].length; q++) {
		
			System.out.print(a[i][j][q] + "  ");
		
		}
		
		System.out.println();
		
		}
		
		System.out.println();
	}

		
	}
}
