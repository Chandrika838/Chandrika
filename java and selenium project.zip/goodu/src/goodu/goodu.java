package goodu;

public class goodu {

	public static void main(String[] args) {
	
      sum(9,6);
	}

	
	public static int sum(int a, int b) { // this sum will be called from the following statement from sum // void is called as return it ll be only return in java  
		int sum= a+b;
		return  sum;
	}
}
