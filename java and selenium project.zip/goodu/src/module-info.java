/**
 * 
 */
/**
 * 
 */
module goodu {
}