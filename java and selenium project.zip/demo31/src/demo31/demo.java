package demo31;


// class in java 
public class demo {

	public static void main(String[] args) {
		// object 
		
		
		car c = new car();
		
		c.carModel = "A model";
		c.carCost = 400000;
		
		
		c.startCar();
		c.stopCar();
		
		// this is are the method  which we use in the inhertiacne in class
	Benz b= new Benz();
	
	b.carModel = "B Class";
	b.carCost = 450000;
	b.startCar();
	b.stopCar();
	
	// same 
	
	Benz d = new Benz();
	d.carCost = 450000;
	d.carModel = "C Model";
	d.startCar();
	d.stopCar();
	d.openroof();
	
	
	
	
	
	
	
	
	

	}

}
