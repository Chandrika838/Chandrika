package demo31;

public class car {
	
	String carModel;
	int carCost;
	
	//
	public void startCar() {
		
		
	}
	
	public void stopCar() {
		
		 
	}

}
