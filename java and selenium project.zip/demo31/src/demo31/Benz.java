package demo31;

public class Benz extends car {
	
	int numberofgears;
	public void openroof () {
		
	}
	

	
}
