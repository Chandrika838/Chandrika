package demo4;

public class demo4 {
 
	public static void main(String[] agrs) {
		
		Employeedetails e1 = new Employeedetails();
		
		e1. name = "Chandrika";
		e1.salary = 30000;
		
		e1.details();
		
	}
}

class Employeedetails {
	
	String name;
	int salary ;
	

		void details() {
		System.out.println("Name :" + name);
		System.out.println("Salary :" + salary);
		

	}
	
	
}