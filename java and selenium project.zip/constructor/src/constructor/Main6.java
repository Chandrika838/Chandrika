package constructor;

public class Main6 {

	public static void main(String[] args) {
	
		Mobile m1 = new Mobile();
		Mobile m3 = new Mobile("Samsung");
		Mobile m4 = new Mobile("iphone" , 8000);
	Mobile m5 = new Mobile("One Plus" ,50000 , "7pro");

	
	m3.display();
	m4.display();
	m5.display();
	
	}

}


