package constructor;

public class Student1 {

	String name ;
	int age;
	int marks;
	
	
	Student1() {
		
		System.out.println("Default constructor");
		
	}
	
 Student1(String n) {
	 name = n;
	
	 
 }
 
 Student1(String n , int a ) {
	 name = n;
	 age = a;
	
 }
 
 Student1(String n , int a, int m) {
	 
	 name = n; 
	 age = a;
	 marks = m;
	 
 }
 
 
 
 void display() {
	 System.out.println(name +" " + age +" "  + marks );
 }
}
