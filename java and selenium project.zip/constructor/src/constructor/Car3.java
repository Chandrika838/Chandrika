package constructor;

public class Car3 {

	public Car3() {
		
		this (3);
		System.out.println("Inside car Cosntructor No paramtere");
	}
	public Car3(int x) {
		 // this is use for the constructor when we want to call two constructor at a time 
		
		this(4,5);
		System.out.println("Inside Car Constructor : " +x);
	}
	
	public Car3(int x ,int y) {
		
	
		System.out.println("Inside Car Constructor :"+ x +y);
		
	}
}
