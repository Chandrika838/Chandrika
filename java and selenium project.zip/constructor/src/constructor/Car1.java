package constructor;

public class Car1 {
	// parameterized constructor 
	String carModel;
	int carCost;
	String carColr;
	
	public Car1 (String cM, int cC, String cCol) { // parameterized constructor 
		carModel =cM;
		carCost = cC;
		carColr = cCol;
		
				
	}

	public void carDetails() {
		
		System.out.println("Model of the car is" + carModel);
		System.out.println("Cost of the car is" + carCost);
		System.out.println("Color" + carColr);

	} 

}
