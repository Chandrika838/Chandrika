package constructor;

public class Demo3 {

	public static void main(String[] args) {
		
		childclass object = new childclass();
		// if u didnt call or call java will automatacted will add it 
	}

}
