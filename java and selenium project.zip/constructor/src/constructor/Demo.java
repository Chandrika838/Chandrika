package constructor;

public class Demo {
	
	public static void main(String[] agrs) {

	// method 
	Car  c = new Car();
	
	c.starCar();
}
}
 
// constructor

