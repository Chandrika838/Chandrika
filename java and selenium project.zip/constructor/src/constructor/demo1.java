package constructor;

public class demo1 {
 
	public static void main(String[] agrs) {
		Car1 c = new Car1("Swift",80000, "red");
		
		c.carDetails();
	
		
			
		}
		
	}

