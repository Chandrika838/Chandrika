package constructor;

public class parentclass {

	public parentclass() {
		
		System.out.println("Inside parent class constructor");
	}
	public parentclass(int a , int b) { // parameter class 
		System.out.println("Inside parent class constructor");
		
	}
 }
