package constructor;

public class Main2 {

	public static void main(String[] args) {
	
		Defaultconstructor d1 = new Defaultconstructor();
		
		d1.show();
	}

}
