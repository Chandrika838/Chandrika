package constructor;

public class Main5 {

	public static void main(String[] args) {
		
		Bank b1 = new Bank();
		Bank b2 = new Bank("Chandrika");
		Bank b3 = new Bank("Ravi" ,5000);

	b1.display();
	b2.display();
	b3.display();
	
	}

}
