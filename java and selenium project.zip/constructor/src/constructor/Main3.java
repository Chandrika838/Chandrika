package constructor;

public class Main3 {

	public static void main(String[] args) {
	
		Book b1 = new Book();
		Book b2 = new Book("Java");
		Book b3 = new Book ("Python ", 5000);
		
		
		b1.display();
		b2.display();
		b3.display();
	}

}
