package constructor;

public class Book {

	// creating the variable 
	
	String title;
	int price ;
	
// Constructor 1
	
	Book() {
		title = "Unknow";
		price = 0;
		
		
	}
	
Book(String t) {
	title = t;
	price = 1000;
	
	
}

Book(String t , int p) {
	
	title = t;
	price = p;
	
	
}

void display() {
	
	System.out.println(title + " " + price);
}

}


