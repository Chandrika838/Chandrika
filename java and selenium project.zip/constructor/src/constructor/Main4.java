package constructor;

public class Main4 {

	public static void main(String[] args) {

		Student1 c1 = new Student1();
		
		Student1 c2 = new Student1("Chandrika");
		Student1 c3 = new Student1("priya", 23 );
		
        Student1 c4 = new Student1("anaya" , 23, 30);
	  
        
        c1.display();
        c2.display();
       c3.display();
       c4.display();
	
	}
	

}
