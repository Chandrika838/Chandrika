package constructor;

public class Defaultconstructor {

	String studentName;
	int  studentID;
	int studentAge;
	
	// default constructor 
	
	public Defaultconstructor () {
		
		studentName = "Chandrika";
		studentID = 2000;
		studentAge = 28;
	}
		
		public void show() {
			
			System.out.println("Student Name is :" + studentName);
			System.out.println("Student ID is :" + studentID);
			System.out.println("Student Age is:" + studentAge);
		}
		
	}

