package constructor;

public class Main1 {

	public static void main(String[] args) {
		
		OnlineOrder o1 = new OnlineOrder(101,"Laptop");
		
	
	
	 // you have to create the child class for the object 
		
	}

}
