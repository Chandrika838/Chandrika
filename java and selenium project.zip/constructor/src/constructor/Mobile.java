package constructor;

public class Mobile {

	String name;
	int price;
	String model;
	
	
	// Constructor 1 
	Mobile() {
		
		System.out.println("Default Constructor");
		
	}
	
	// constructor 2 name only 
	Mobile(String n) {
		name = n;
		
	}
		
	// constructor 3;
		
		Mobile(String n, int p) {
			
			name = n;
			price =p;
				
		}
		
		// Constructor 4 
	Mobile(String n , int p ,String m) {
	
	name = n;
	price = p;
	model = m;
		
	}
	void display() {
		System.out.println(name + "" + price + "" + model);
	}
	}

