package constructor;

public class vehicle {
 
	// instance variable 
	
	String carModel;
	int carSpeed ;
	String carName;
	Double carMilege;
	

	public vehicle(String cM, int cS, String cN, Double cD ){
	
		carModel = cM;
		carSpeed = cS;
		carName = cN;
		carMilege = cD;
			
	}
	
	public void vehicleDetails() {
		
		System.out.println("CarModel:is" + carModel);
		System.out.println("Model of the car is:" + carSpeed);
		System.out.println("Name of the car is:" + carName);
		System.out.println("Milege of the car is:" + carMilege);
	}
	
}

