package constructor;

public class Browser {

		
		String BrowserName;
		
	// Parent Constructor 
		
		Browser(String BrowserName) { // parameterzied constructor 
			this.BrowserName =BrowserName;
			System.out.println("Lauch the messg :" + BrowserName);
		}
		
	}

// child class 
class LoginTest extends Browser {
	
	String userName;
	
	// child constructor 
	
	LoginTest(String BrowserName,String userName) {
		super(BrowserName); // calling parent constructor
		
		this.userName = userName;
	
	
		System.out.println("Student id is created in the class id ");
	}
	
	void executeTest() { // this is a method where we called the child class from the class 
		System.out.println("Test executed successfully");
}


	
}