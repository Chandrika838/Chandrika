package constructor;

public class Main {

	public static void main(String[] args) {
		 Student s1 = new Student("Chandu", "Bangalore", 85, 22);

		 // calling correct method 
		 
		 s1.studentDetials();
	
	
	} 
}
