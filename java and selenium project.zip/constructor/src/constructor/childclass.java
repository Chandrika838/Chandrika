package constructor;

public class childclass extends parentclass {

	public childclass() {
		
		super(); // super calling sttement will call parent class will be execute 
		System.out.println("Insdie the child class");
		
		
	}
	public childclass(int a) {
	System.out.println("Inside the child class");
		
	}
}
