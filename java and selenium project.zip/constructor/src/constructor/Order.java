package constructor;

public class Order {

	int orderID;
	
	Order(int orderID) {
		this.orderID = orderID;
		System.out.println("Order ID :"+orderID);
		
	}
}


class OnlineOrder extends Order {
	
	String productName;
	
	OnlineOrder(int OrderID , String productName) {
		
		super(OrderID); // calling the parent constructor 
		
		this.productName = productName;
		System.out.println("Product :" + productName);
	}
}

