package constructor;

public class Car2 {
// Instance variable 
	String carModel;
	int carCost;
	double carMilage;
	
	
	// constructor 
	public Car2(String cModel, int cCost, double cMilage) { // parameter 
		// intilizalation paramter 
		
		this.carModel = carModel; // instance variable  to not to get the conusion in the instant variable we can use the symbol where it will be separate instance and parameter both 
		this.carCost = carCost;
		this.carMilage = carMilage;
	}
}
