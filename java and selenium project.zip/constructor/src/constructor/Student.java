package constructor;

public class Student {

	String studentName;
	String studentAddress;
	int studentMarks;
	int studentAge;
	
	// parameterized Constructor 
	
	public  Student(String sN,String sA, int sM, int sD ) {
		
		studentName = sN;
		studentAddress = sA;
		studentMarks = sM;
		studentAge = sD;
		
		
	}
		
	public void studentDetials() {
		System.out.println("Student name is:" + studentName);
		System.out.println("Student Address is:" + studentAddress);
		System.out.println("Student Marks is :" + studentMarks);
		System.out.println("Student Age is:" + studentAge);
		
	}
}


	

