package constructor;

public class Bank {

	String name;
	double balance ;
	
// constructor 1 
	Bank() {
		
	System.out.println("Default constructor");
	}
	
	// constructor 2
	Bank(String n) {
		name = n;
	}
		
	// Constructor 3
		
	Bank(String n , double b){
		name = n;
		balance = b;
	}
	
		void display() {
			System.out.println(name + "" + balance );
			
		}
	}

