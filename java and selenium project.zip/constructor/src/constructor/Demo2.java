package constructor;

public class Demo2 {

	public static void main(String[] args) {
	
		Car3 c = new Car3();// this is use to call the constructor if we don't have a constructor name with it will run saying no parameter 
		
		

	}

}
