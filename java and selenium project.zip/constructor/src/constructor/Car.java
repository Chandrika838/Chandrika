package constructor;

public class Car {

	String carModel;
	
	// constructors 
	
	public Car() {
		
		System.out.println("Inside the car");
	}
	// method 
	
	public void starCar() {
		System.out.println("Inside method");
		
	}
}
