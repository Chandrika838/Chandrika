package overiddingmethod1;

public class Main1overidding {

	public static void main(String[] agrs) {
		
		Payment p;
		
		p = new UPI();
		p.pay();
		
		p= new Card();
		p.pay();

		
		
	}
}
