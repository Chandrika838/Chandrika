package overiddingmethod1;

public class Main2Animal {

	public static void main(String[] args) {
	
		Animal a = new Dog();
		
		a.sound();
		
		Animal b = new cat();
		b.sound();
		
		

	}

}
