package overiddingmethod1;

public class Payment {

	void pay() {
		
		System.out.println("Payment method");
		
	}
}

class UPI extends Payment {
	
	void pay() {
		
		System.out.println("Paid using UPI");
	}
	
}


class Card extends Payment {
	
	void pay() {
		
		System.out.println("Paid using card");
	}
}