package overiddingmethod1;

public class Browser {

	void open() {
		
		System.out.println("opening browser");
		
	}
}

class chrome extends Browser {
	
	void open() {
		
		System.out.println("Opening chrome browser");
	}
}


class Edge extends Browser {
	
	void open() {
		
		System.out.println("Opening edge browser");
	}
}
