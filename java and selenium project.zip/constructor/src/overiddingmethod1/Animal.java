package overiddingmethod1;

public class Animal {

	// override method 
	
	void sound() {
		
		System.out.println("Animal sound");
		
	}
}

class Dog extends Animal {
	
	void sound() {
		
		System.out.println("Dog is barking");
		
	}
}

class cat extends Animal {
	
	void sound () {
		
		System.out.println("Cat is saying meyow");
	}
}
