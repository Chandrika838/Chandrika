package overiddingmethod1;

public class Main3Browser {

	public static void main(String[] args) {
		
		// calling the method 
		
		Browser b = new chrome();
		Browser c = new Edge();
		
		b.open();
		c.open();
		
		
		
	
		

	}

}
