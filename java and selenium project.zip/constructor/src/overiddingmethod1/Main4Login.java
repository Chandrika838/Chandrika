package overiddingmethod1;

public class Main4Login {

	public static void main(String[] args) {
		
		Login l ;
		
		l = new Googlelogin();
		l.login();
		
		l  = new Facebooklogin();
		
		l.login();
		
		l = new Emaillogin();
		
		l.login();	
		
	}

}
