package overiddingmethod1;

public class Login {

	void login() {
		
		System.out.println("Login using basic method");
			
	}
}


 class Googlelogin extends Login {
	 
	 void login() {
		 
		 System.out.println("Login using through google account");
	 }
 }
 
 
 class Facebooklogin extends Login {
	 
	 void login() {
		 
		 System.out.println("Login using through facebook account");
	 }
 }
 
 
 class Emaillogin extends Login {
	 
	 void login() {
		 
		 System.out.println("Login using through Email login account");
	 }
	 
	 
 }

	  
  