/**
 * 
 */
/**
 * 
 */
module objectionorientendprogram {
}