package objectionorientendprogram;

public class Student {

	private int Marks;
	
	public void setMarks(int m) {
		
		Marks = m;
	}
	
	public int getMarks() {
		
		return Marks;
		
	}
}
