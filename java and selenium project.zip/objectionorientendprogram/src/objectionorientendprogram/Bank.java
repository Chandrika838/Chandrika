package objectionorientendprogram;

public class Bank {

	private String accountholder;
	private int  Balance;
	
	// set account 
	
	public void setAccountHolder(String name) {
		
		accountholder = name;
	}
	
	// deposit money 
	
	public void deposit(int amount) {
		
		Balance = Balance + amount;
		
		System.out.println( amount + "desposited");
	}
	
	public void withdraw(int amount) {
		
		if (amount <= Balance) {
			
			Balance = Balance - amount;
			System.out.println(amount + "withdrawn");
		} else {
			
			System.out.println("Insufficient balance");
		}
			
		}
		// display
		
		public void showDetails() {
			
			System.out.println("Name :" + accountholder);
			System.out.println("Balance :" + Balance);
			
		
	}
	
}
