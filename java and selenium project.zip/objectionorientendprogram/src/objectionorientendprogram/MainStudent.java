package objectionorientendprogram;

public class MainStudent {

	public static void main(String[] args) {
	
		// Method calling 
		
		Student s = new Student();
		
		s.setMarks(50);
		
		System.out.println("Student :" + s.getMarks());
	}

}
