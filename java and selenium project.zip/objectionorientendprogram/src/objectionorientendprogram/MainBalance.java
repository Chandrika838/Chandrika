package objectionorientendprogram;

public class MainBalance {

	public static void main(String[]agrs) {
		
		Bank b = new Bank();
		
	b.setAccountHolder("Chandrika");
	b.showDetails();
	b.withdraw(50000);
	b.deposit(200);
	}
	
	
}
