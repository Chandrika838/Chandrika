package objectionorientendprogram;

public class Main {

	public static void main(String[] args) {
		
	// calling the method 
		
		BankAccount acc = new BankAccount();
		
		acc.setBalance(10000); // setting value 
		
		System.out.println("Balance :" + acc.getBalance() );
		
		
	}

}
