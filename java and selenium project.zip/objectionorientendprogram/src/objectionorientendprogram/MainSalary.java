package objectionorientendprogram;

public class MainSalary {

	public static void main(String[] args) {
	
	Employee e = new Employee ();
			
		e.setSalary(20000);
		
	System.out.println("Salary :" + e.getSalary());
		
	}

}
