package objectionorientendprogram;

public class Mobile {

	private int price;
	
	public void setprice(int p) {
		
		price = p;
		
	}
	
	public int getprice() {
		
		return price;
		
		
	}
}
