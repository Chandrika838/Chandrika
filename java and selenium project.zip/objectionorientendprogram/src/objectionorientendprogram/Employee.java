package objectionorientendprogram;

public class Employee {

	private int Salary;
	
	public void setSalary(int s) {
		Salary = s;
		
	}
	
	public int getSalary() {
		return Salary;
		
	}
}
