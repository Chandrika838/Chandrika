package objectionorientendprogram;

public class BankAccount {

	
	private int balance; // hide data 
	
	// method to set balance 
	
	
	public void setBalance(int b) {
		
		balance = b;
		
		// method use for get balance method 
		
			
		}
	

	public int getBalance() {
		
		return balance;
		
	}



		
	}
	
	
