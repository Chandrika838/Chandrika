package objectionorientendprogram;

public class mobilemain {

	public static void main(String[] args) {

 Mobile p = new Mobile();
 
 p.setprice(20000);
 
 System.out.println("Mobile price :" + p.getprice());
	 
 }
		
	}


