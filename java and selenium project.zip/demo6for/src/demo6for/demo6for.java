package demo6for;

public class demo6for {

	
	public static void main(String[]agrs) {
	
		int [] a  = {1,2,3,4,5,6,7,8,9,0,56,7,8,9};
		
		// for each loop  is the process where it check the process and execute one by one in java and it will iterate in the loop for every number will be iternative that many times in for each time and for each loop is used only in arrays and collection  
		
		for(int temp: a) {    // for loop syntax 
			
			System.out.println(temp);
		}
	}
}
