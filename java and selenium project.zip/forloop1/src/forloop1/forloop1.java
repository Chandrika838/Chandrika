package forloop1;

public class forloop1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i;// declaration // in case if i dont want to declare the inzilation i ll use the for statement in the statement 

		for( i =0;i <5;i++) {// there is a increment and condition and statement in this sentence ;
			
			System.out.println("QA Fox :"+ i); // incase i want to print including i also in the statement then we should i also 
	}

	}
	
}
