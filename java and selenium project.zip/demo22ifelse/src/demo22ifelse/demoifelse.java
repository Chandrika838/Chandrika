package demo22ifelse;

public class demoifelse {

	public static void main(String[] args) {
	
		int num = 14;
		
		if (num %2 ==0) { // this check the remain is == 0 then it will print it 
			
			System.out.println("even");
			
		}else {
			System.out.println("odd");
		}

	}

}
