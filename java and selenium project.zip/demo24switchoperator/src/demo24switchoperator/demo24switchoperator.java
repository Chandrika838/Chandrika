package demo24switchoperator;

import java.util.Scanner;
public class demo24switchoperator {


	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Enter the number (1-7):");
		int day = sc.nextInt();
		
		switch(day) {
		
		case 1:
			System.out.println("Monday");
			
			break;
			
		case 2:
			System.out.println("Tuesday");
			break;
			
		case 3:
			
			System.out.println("Wednesday");
			break;
			
		case 4:
			System.out.println("Thursday");
			
			break;
			
		case 5:
			System.out.println("Firday");
			break;
			
		case 6:
			System.out.println("Saturday");
			default:
				
			System.out.println("Invalid option");
		}
		

	}
	
}


