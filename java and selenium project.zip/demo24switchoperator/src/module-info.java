/**
 * 
 */
/**
 * 
 */
module demo24switchoperator {
}