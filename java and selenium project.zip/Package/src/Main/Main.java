package Main;

import pack1.pack1;

public class Main {

	public static void main(String[] agrs) {
		
		pack1 p1 = new pack1();
		p1.show();
		
		pack2.pack2 p2 = new pack2.pack2();
		p2.show();
		
		
	}
}
