package pack1;

public class pack1 {

	public void show() {
		
		System.out.println("Pack1 Demo");
		
	}
}
