package pack2;

public class pack2 {
	public void show() {
		
		System.out.println("Pack2 Demo");
		
		
	}
}
