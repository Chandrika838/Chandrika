package demo24ifelse;

public class demo24ifelse {

	public static void main(String[] args) {
		
		int marks = 85;
		
		if (marks >= 90) {
			
			System.out.println("A");
			
		} else if (marks >= 75) {
			System.out.println("B");
			
		} else if (marks >= 85) {
			
			System.out.println("C");
			
		} else {
			
			System.out.println("D");
		
			
			
			
			
			
		}
		}
}
	
	
		
		
		

		
