package demo12classmarks;

public class demo12classmarks {

	public static void main(String[] args) {
		
		// Creating objects 
		Student s1 = new Student();
		Student s2 = new Student();
		
		// Set data // method 
		
		s1. setdata ("Chandrika" ,28, 72);
		s1. setdata ("ravi" , 27, 65);
		
		// dispaly details 
		
		s1. display();
		s1. checkresult ();
		
		System.out.println("------------");
		
		s2. display();
		s2.checkresult();
		

	}

}


class Student {
	
	String name ;
	int age;
	int marks;
	
	// Method to set data 
	
	
	void setdata(String n, int a, int m) {
		
		name = n;
		age = a; 
		marks = m;
		
	}
	
	// method dispaly details 
	
	void display() {
		
		System.out.println("Name" + name);
		System.out.println("age:" + age);
		System.out.println("Marks" + marks);
		
	}
	
	// check the results 
	
	void checkresult() {
		
		if (marks >= 40) {
			
			System.out.println("Result :Pass");
			
		}else {
			System.out.println("Result : Fail");
			
			
			
			
		}
	
	
	
	
	}
}