package com.mypc.automation.admintestcase;

import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.adminpage.ComputerPage;
import com.mypc.automation.pages.pages.LoginPage;

public class ComputerTestCase extends BaseTest{


    @Test
    public void verifyAddComputer() {

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        ComputerPage computerPage = new ComputerPage(driver);

        computerPage.ClickAdmin();

        computerPage.ClickComputers();

        computerPage.ClickAddNew();

        computerPage.enterComputerName(config.getComputerName());

        computerPage.enterComputerID(config.getComputerID());

        computerPage.selectLocation(config.getLocation1());

        computerPage.ClickAdvancedOption();

        computerPage.enterNoShowWaitTime(config.getnoshowwaitTime());

        computerPage.enterLevel1Warning(config.getLevelWarnining());

        computerPage.enterLevel2Warning(config.getLevelWarning2());

        computerPage.enterLevel3Warning(config.getLevelLevelWarning3());

        computerPage.clickLoggingLevel();

        computerPage.enableShowWelcomeMessage();

        computerPage.enableShowAUPMessage();

        computerPage.enterInactivityTimeout(config.getInactivityTimeout());

        computerPage.enterLockTimeout(config.getLockTime());

        computerPage.ClickAutoReboot();

        computerPage.ClickAutoShutdown();

        computerPage.clickAdd();
        
        
    }
}