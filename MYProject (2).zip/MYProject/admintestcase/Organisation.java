package com.mypc.automation.admintestcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.adminpage.OrganisationPage;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.adminpage.OrganisationPage;
import com.mypc.automation.pages.utils.ConfigReader;

public class Organisation extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyOrganisationSettings() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(config.getEmail(), config.getPassword());

        // Admin Page
        OrganisationPage admin = new OrganisationPage(driver);
        
       

        // Open Admin
        admin.clickAdminMenu();

        // Open Organisation
        admin.clickOrganisation();

        // Select Time Zone
        admin.selectTimeZone(config.gettimeZone());
        
        Assert.assertTrue(admin.isTimeZoneDisplayed(),"Time Zone is not Displayed ");
        

        // Click Advanced Options
        admin.clickAdvancedOption();

        // Authentication Checkboxes
        String[] checkBoxIds = {

                "allowAuthRezzervi",
                "allowAuthGoogle",
                "allowAuthMicrosoft",
                "allowAuthEntraID"
        };

        for (String id : checkBoxIds) {

            admin.enableCheckBox(id);
        }

        // Tooltip Checkboxes

        admin.enableCheckBox("showBookingTooltipForOthers");
        admin.enableCheckBox("showUsername");
        
        
        
       
        
       
        // Resource Checkboxes

        String[] resources = {

                "showRoom",
                "showDesk",
                "showPc"
        };

        for (String id : resources) {

            admin.enableCheckBox(id);
        }

        
        Assert.assertTrue(admin.isDisplayedSubmit(),"Submit is not Displayed");
        
        // Save Changes
        admin.clickSubmit();
    }
}