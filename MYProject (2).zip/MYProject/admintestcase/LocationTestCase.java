package com.mypc.automation.admintestcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.Location;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.utils.ConfigReader;

public class LocationTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyAddLocation() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(config.getEmail(), config.getPassword());

        // Location Page
        Location locationPage = new Location(driver);

        // Verify and click Admin
        Assert.assertTrue(locationPage.isAdminDisplayed(),
                "Admin is not displayed");

        locationPage.clickAdmin();

        // Verify and click Location
        Assert.assertTrue(locationPage.isLocationDisplayed(),
                "Location is not displayed");

        locationPage.clickLocation();

        // Click Add New
        locationPage.clickAddNew();

        // Enter Location Name
        locationPage.enterLocatioName(config.getLocation());

        // Click Advanced Options
        locationPage.clickAdvancedOptions();
        
        locationPage.SelectParentLocation(config.getparentLocation());
        
     //   locationPage.SelectTimeZone(config.gettimeZone());

        // Submit
        locationPage.ClickSubmit();
        
        
        
    }
}