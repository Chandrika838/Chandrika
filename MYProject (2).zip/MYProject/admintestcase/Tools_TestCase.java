package com.mypc.automation.admintestcase;

import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.adminpage.ToolsPage;
import com.mypc.automation.pages.utils.ConfigReader;

public class Tools_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyAddTools() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(config.getEmail(), config.getPassword());

        // Tools Page
        ToolsPage toolsPage = new ToolsPage(driver);

        toolsPage.Clickadmin();

        toolsPage.ClickTools();

        toolsPage.ClickUsers();

        toolsPage.ClickTags();

        toolsPage.Clickaddnew();

        toolsPage.enterTagName("Automation Tags");

        toolsPage.clickAdd();
    }
}
