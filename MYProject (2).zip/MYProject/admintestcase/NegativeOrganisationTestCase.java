package com.mypc.automation.admintestcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.adminpage.OrganisationPage;
import com.mypc.automation.pages.pages.LoginPage;

public class NegativeOrganisationTestCase extends BaseTest{


	@Test
	
	public void verifyAuthenticationUser() {
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		
		loginPage.enterPassword(config.getPassword());
		
		loginPage.clickLogin();
		
		
		OrganisationPage org = new OrganisationPage(driver);
		
		org.clickAdminMenu();
		
		org.clickOrganisation();
		
		org.clickAdvancedOption();
		org.disableAllUser();
		org.clickSubmit();
		
		
		Assert.assertEquals(
		        org.getValidationMessage(),
		        "Invalid entry!",
		        "Validation message is incorrect.");
	
		
	

	Assert.assertEquals(org.getInvalidMessage(), "validation message is incorrect");
	
	}

}

