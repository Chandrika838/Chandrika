package com.mypc.automation.reports.tests.UserTools;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.UserToolPage.*;
import com.mypc.automation.pages.utils.ConfigReader;

import org.testng.Assert;
import org.testng.annotations.Test;

public class UserTags extends BaseTest{
	
	ConfigReader config = new ConfigReader();
	
	@Test
	
 public void verifyAddUserTestCase() {
		
	
		LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.enableHighContrast();
        loginPage.clickLogin();

        UsersTags Users = new UsersTags(driver);

        Users.ClickAdmin();
        Users.ClickTools();
        Users.ClickUsersTool();
        Users.ClickTags();
        Users.ClickAddNew();

        String tagName = config.getUsersTag();

        System.out.println("Tag Name = " + tagName);

        Users.enterUsersTag(tagName);

        Users.clickAdd();
      
        
        Assert.assertTrue(Users.isDisplayedAddSubmit(), "Submit is not Displayed");
        
    }
  
	}




