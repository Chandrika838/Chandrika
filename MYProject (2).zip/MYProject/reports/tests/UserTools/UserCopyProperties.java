package com.mypc.automation.reports.tests.UserTools;

import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.pages.copyproperties.UserCopyPropertiesPage;
import com.mypc.automation.pages.utils.ConfigReader;

public class UserCopyPropertiesTest extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyAddUsers() {

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        UserCopyPropertiesTest users = new UserCopyPropertiesTest(driver);

        users.clickAdmin();
        users.clickTools();
        users.ClickUsers();
        users.ClickCopyProperties();

        String[] checkBoxes = {

                "tag_b28410dd-7332-42f6-9863-019f501d4b97",
                "setting_USER_ROLE",
                "setting_TAGS"
        };

        for (String id : checkBoxes) {

            users.enableCheckbox(id);
        }

        users.clickCopy();
    }
}
	
	


