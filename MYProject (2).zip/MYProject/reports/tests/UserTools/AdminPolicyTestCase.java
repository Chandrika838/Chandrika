package com.mypc.automation.reports.tests.UserTools;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.UserToolPage.AdminPolicy;
import com.mypc.automation.pages.utils.ConfigReader;

public class AdminPolicyTestCase extends BaseTest{
	
	ConfigReader config = new ConfigReader();
	
	@ Test
	
	public void verifyAddTestCase() {
		
		LoginPage loginPage = new LoginPage(driver);
		
		
		loginPage.enterEmail(config.getEmail());
		loginPage.enterPassword(config.getPassword());
		
		loginPage.clickLogin();
		
		
		// creating a constructor for Test Case 
		
	AdminPolicy Admin = new  AdminPolicy(driver);
	
	Admin.ClickAdmin();
	
	Admin.clickTools();
	
	Admin.ClickUsersTools();
	
	Admin.ClickAdminpolicy();
	
	Admin.ClickAddnew();
	
	Admin.selectUserTag(config.getUserTag());
	
	Admin.SelectAdminPolicy(config.getAdminPolicy());
	
	//Admin.ClickCancel();
	
	Assert.assertTrue(Admin.isSubmitDisplayed(),"Submit is not displayed");
	Admin.ClickSubmit();
	

	}


}
