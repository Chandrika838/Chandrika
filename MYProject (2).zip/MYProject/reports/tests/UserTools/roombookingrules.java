package com.mypc.automation.reports.tests.UserTools;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.pages.usersbooking.*;
import com.mypc.automation.pages.utils.ConfigReader;

import org.testng.Assert;
import org.testng.annotations.Test;

public class roombookingrules extends BaseTest {

	ConfigReader config = new ConfigReader();
	
	@Test
	
	public void verifyAddRoom() {
		
LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		
		loginPage.enterPassword(config.getPassword());
		
		loginPage.clickLogin();
	
	
	RoomPage Users = new RoomPage(driver);
	
	Users.ClickAdmin();
	
	Users.ClickTools();
	
	Users.ClicUser();
	
	Users.ClickBookingRules();
	
	Users.ClickRooms();
	
	Users.ClickAllusers();
	
	Users.ClickAccess();
	
	Assert.assertTrue(Users.isAccessSelected(),"Access is not selected");
	
	
	Users.enablemaxiumBookingPerMonth("1000");
	
	Assert.assertTrue(Users.isMaxiumBookingperMonthDisplayed(), "Maxium Booking per Month is not displayed");
	
	Users.enablemaxiumByDuration("20");
	
	Assert.assertTrue(Users.isMaxiumByDurationDisplayed(), "Maxium by Duration is not displayed");
	
	Users.enableNumberofbooking("10");
	
	Assert.assertTrue(Users.isNumberofBookingDisplayed(), "Number of Booking is not displayed");
	
	Users.enableMaximumallowedperday("4");
	
	Assert.assertTrue(Users.MaxiumallowedperdayDisplayed(), "Maxiuma allowed per day is not displayec");
	
	Users.enableMaximunPeriodadvance("1450");
	
	Users.ClickcanMake();
	
	Assert.assertTrue(Users.isSelectedCanMake(), "Can Make is not displayed");
	
	Users.enableMaxmium("3");
	
	Users.ClickCancel();
	
	Users.ClickSubmit();
	
	
	
	}
	
}
	

