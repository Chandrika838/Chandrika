package com.mypc.automation.reports.tests.UserTools;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.pages.bookingrulestags.*;
import com.mypc.automation.pages.utils.ConfigReader;

import org.testng.Assert;
import org.testng.annotations.Test;

public class usersbookingrulestags extends BaseTest{

	
	ConfigReader config = new ConfigReader();
	
	@Test
	
	public void VerifyAddUserTestCase() {
		
		
	
		LoginPage loginPage = new LoginPage(driver);

		loginPage.enterEmail(config.getEmail());
		loginPage.enterPassword(config.getPassword());

		loginPage.clickLogin();


		// creating the constructor for the Room Test case


		Userspage users = new Userspage(driver); 
			
		users.ClickAdmin();

		users.ClickTools();
		users.ClickUsers();
		users.ClickTags();

		users.ClickTool();

		users.ClickBookingRules();
		
        users.ClickBookingRules1();
        
        users.ClickBookingRules2();
        
        users.ClickBookingRules3();
	
		users.ClickUpdate();

		Assert.assertTrue(users.isDisplayedUpdate(),"Update is not Displayed");

		
		}
			}


