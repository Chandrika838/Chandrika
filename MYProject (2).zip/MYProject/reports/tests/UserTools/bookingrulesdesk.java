package com.mypc.automation.reports.tests.UserTools;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.pages.usersbooking.*;
import com.mypc.automation.pages.utils.ConfigReader;

import org.testng.Assert;
import org.testng.annotations.Test;

public class bookingrulesdesk extends BaseTest {

	ConfigReader config = new ConfigReader();
	
	
	@Test
	
	public void VerifyAddDesk() {
		
LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		
		loginPage.enterPassword(config.getPassword());
		
		loginPage.clickLogin();
	
	
	Desk desk = new Desk(driver);
	
	desk.ClickAdmin();
	
	desk.ClickTools();
	
	desk.ClicUser();
	
	desk.ClickBookingRules();
	
	desk.ClickRooms();
	
	desk.ClickAllusers();
	
	desk.ClickAccess();
	
	Assert.assertTrue(desk.AccessisSelected(), "Access is not Selected");
	
	desk.enablemaxiumBookingPerMonth("1000");
	
    Assert.assertTrue(desk.MaxiumBookingPerMonthDisplayed(), "Maxmium booking Per Month is not dsiplayed");
    
	desk.enablemaxiumByDuration("20");
	
	Assert.assertTrue(desk.MaxiumByDurationDisplayed(), "Maxium By Duration is not Displayed");
	
	
	desk.enableNumberofbooking("10");
	
	desk.enableMaximumallowedperday("4");
	
	desk.enableMaximunPeriodadvance("1450");
	
	Assert.assertTrue(desk.isDisplayedMaximumPeriodadvance() ,"Maximun allowed per day is not displayed");
	
	desk.ClickcanMake();
	
	Assert.assertTrue(desk.isSelectedCanMake(), "Can Make is not selected");
	
	desk.enableMaxmium("3");
	
	desk.ClickCancel();
	
	desk.ClickSubmit();
	
		
	}
}
