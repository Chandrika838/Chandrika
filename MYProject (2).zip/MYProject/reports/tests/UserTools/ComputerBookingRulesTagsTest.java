

package com.mypc.automation.reports.tests.UserTools;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.UserToolPage.*;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.pages.usersbooking.ComputerPage;
import com.mypc.automation.pages.utils.ConfigReader;

public class ComputerBookingRulesTagsTest extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyAddComputerTestCase() {

        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(config.getEmail(), config.getPassword());

        ComputerPage comp =
                new ComputerPage(driver);

        comp.ClickAdmin();
        comp.ClickTools();
        comp.ClickComputers();
        comp

        comp.ClickTool();
        comp.ClickBookingRules();

        comp.ClickAddNew();

        Assert.assertTrue(
                comp.isDisplayedAddNew(),
                "Add New is not Displayed");

        comp.SelectID(config.getUsersTag());

        comp.ClickDesk();

        comp.ClickAddNew1();

        comp.SelectID1(config.getUsersTag());

        comp.ClickContinue();

        Assert.assertTrue(
                comp.isDisplayedContinue(),
                "Continue is not Displayed");

        comp.ClickUpdate();

        Assert.assertTrue(
                comp.isDisplayedUpdate(),
                "Update is not Displayed");

        comp.ClickUpdate1();

        Assert.assertTrue(
                comp.isDisplayedUpdate1(),
                "Update1 is not Displayed");
    }
}