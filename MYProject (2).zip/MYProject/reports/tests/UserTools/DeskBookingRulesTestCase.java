package com.mypc.automation.reports.tests.UserTools;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.desktools.*;
import com.mypc.automation.pages.utils.ConfigReader;

public class DeskBookingRulesTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyDeskTestCase() {

        // Login
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(config.getEmail(), config.getPassword());

        // Page Object
        DeskBookingRules desk = new DeskBookingRules(driver);

        // Navigation
        desk.clickAdmin();
        desk.clickTools();
        desk.ClickDesk();
        desk.clickTools();

        desk.clickTools();
        desk.ClickBookingRules();

        // Add New
        desk.clickAdmin();

        


        // Add New
        desk.ClickAddNew();

        Assert.assertTrue(
                desk.isDisplayedAddNew(),
                "Add New button is not displayed.");

        desk.SelectID(config.getUsersTag());

        // Continue
        desk.ClickContinue();

        Assert.assertTrue(
                desk.isDisplayedContinue(),
                "Continue button is not displayed.");

        // Update
        desk.ClickUpdate();

        Assert.assertTrue(
                desk.isDisplayedUpdate(),
                "Update button is not displayed.");

        desk.ClickUpdate1();

        Assert.assertTrue(
                desk.isDisplayedUpdate1(),
                "Update confirmation button is not displayed.");
    }
}

