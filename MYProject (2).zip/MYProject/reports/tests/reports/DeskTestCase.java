package com.mypc.automation.reports.tests.reports;

import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.pages.reports.DeskPage;
import com.mypc.automation.pages.utils.ConfigReader;

public class DeskTestCase extends BaseTest{

ConfigReader config = new ConfigReader();
	
	@Test
	
	public void VerifyAddDeskTest() {
		
	// creating a constructor for the login Page 
		
   LoginPage loginPage = new LoginPage(driver);
   
   loginPage.enterEmail(config.getEmail());
   loginPage.enterPassword(config.getPassword());
   loginPage.clickLogin();
   
   
// creating an constructor for UserTest Case 
   
   DeskPage desk = new DeskPage(driver);
   desk.ClickReport();
   desk.ClickDeskReport();
   desk.SelectLocation(config.getLocation());
   desk.SelectMonth(config.getperiod());
   desk.SelectBookingType(config.getBookingType());
}

}