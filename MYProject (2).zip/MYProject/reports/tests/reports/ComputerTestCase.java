package com.mypc.automation.reports.tests.reports;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;

import com.mypc.automation.pages.pages.reports.ComputerPage;
import com.mypc.automation.pages.utils.ConfigReader;

public class ComputerTestCase extends BaseTest {

	ConfigReader config = new ConfigReader();
	
	@Test

	public void VerifyAddUserTest() {
		
	// creating a constructor for the login Page 
		
   LoginPage loginPage = new LoginPage(driver);
   
   loginPage.enterEmail(config.getEmail());
   loginPage.enterPassword(config.getPassword());
   loginPage.clickLogin();
   
   
   // creating an constructor for UserTest Case 
   
   ComputerPage comp = new ComputerPage(driver);
   
   comp.ClickReport();
   
   comp.ClickComputerReport();
   
   comp.SelectLocation(config.getLocation());
   
   
   comp.SelectMonth(config.getperiod());
   
   comp.SelectBookingType(config.getBookingType());
   
   comp.ClickPieChart();
   
   Assert.assertTrue(comp.isDisplayedPiechart(),"Pie chart is not displayed ");
   
   
   
	}
}
	

