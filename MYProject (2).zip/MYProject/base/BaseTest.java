package com.mypc.automation.base;

import java.lang.reflect.Method;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.mypc.automation.pages.utils.ConfigReader;
import com.mypc.automation.pages.utils.ExtentManager;

public class BaseTest {

    protected WebDriver driver;
    protected ConfigReader config;
    protected ExtentReports extent;
    protected ExtentTest test;

    @BeforeMethod
    public void setup(Method method) {

        driver = new ChromeDriver();
        config = new ConfigReader();

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
        
        driver.get(config.getUrl());
        
        extent = ExtentManager.getReport();
        
        // extend report 
        
        test = extent.createTest(method.getName());
        
        
    }

    @AfterMethod
    public void tearDown() {

        if (driver != null) {
            driver.quit();
        }
    }
	 

@AfterSuite
//flush reoprt once after all tests
public void tearDownSuite() {
	extent.flush();
}

}
 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 

 

