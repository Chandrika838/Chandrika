package com.mypc.automation.reservebooking;

import java.time.LocalDate;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.reservebooking.Reserve_RoomPage;
import com.mypc.automation.pages.utils.ConfigReader;

public class Reserve_Room_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyReserveRoom() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(config.getEmail(), config.getPassword());

        // Reserve Room Page
        Reserve_RoomPage reserve = new Reserve_RoomPage(driver);

        reserve.clickReserve();

        reserve.clickRoom();

        reserve.selectLocation(config.getLocation());
        
        Assert.assertTrue(reserve.isDisplayedLocation(), "Location is not Selected ");
        
        
        reserve.selectDate(LocalDate.now().plusDays(1));
        

        reserve.clickToolTip();

        reserve.selectStartime(config.getstartTime());

        reserve.clickDragdrop();

        reserve.enableSelfBooking();

        reserve.clickSubmit();
    }
}