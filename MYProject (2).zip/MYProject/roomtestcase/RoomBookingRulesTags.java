package com.mypc.automation.roomtestcase;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.pages.bookingrulestags.*;
import com.mypc.automation.pages.utils.ConfigReader;

import org.testng.Assert;
import org.testng.annotations.Test;

public class RoomBookingRulesTags extends BaseTest {

	ConfigReader config = new  ConfigReader();
	
	
	@Test
	
	public void VerfiyRoomTestCase() {
		
		
		// create the constructor for the loginPage
		
LoginPage loginPage = new LoginPage(driver);

loginPage.enterEmail(config.getEmail());
loginPage.enterPassword(config.getPassword());

loginPage.clickLogin();


// creating the constructor for the Room Test case


RoomPage room = new RoomPage(driver); 
	
room.ClickAdmin();

room.ClickTools();
room.ClickRoom();
room.ClickTags();

room.ClickTool();

room.ClickBookingRules();


room.ClickAddNew();

Assert.assertTrue(room.isDisplayedAddNew(),"Add New is not Displayed");
		
room.SelectID("Automation Tags");

room.ClickContinue();


Assert.assertTrue(room.isDisplayedContinue(),"Continue is not Displayed");

room.ClickUpdate();

Assert.assertTrue(room.isDisplayedUpdate(),"Update is not Displayed");

room.ClickUpdate1();


Assert.assertTrue(room.isDisplayedUpdate1(),"Update1 is not Displayed ");


}
	}

