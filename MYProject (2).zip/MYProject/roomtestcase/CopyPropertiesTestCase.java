package com.mypc.automation.roomtestcase;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.utils.ConfigReader;
import com.mypc.automation.pages.roomtools.CopyProperties;
public class CopyPropertiesTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

  
    @Test
    
    public void VerifyCopyProperties() {
    	
    	

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        
        loginPage.enterPassword(config.getPassword());
        
        loginPage.clickLogin();
        

      // Crreating a Copy Properties constructor 
        
       CopyProperties copy = new CopyProperties(driver);

        copy.ClickAdmin();
        copy.ClickTools();
        copy.ClickRooms();
        copy.ClickCopyProperties();

        copy.SelectSource(config.getroomName());

        copy.SelectLocation("All");

        String[] checkBox = {

                "fd7f1a0b-23ae-4b15-9da8-019f40317e6e",
                "setting_LOCATION",
                "setting_DEFAULT_DURATION",
                "setting_CAPACITY",
                "setting_EQUIPMENT",
                "setting_CHECK_IN_SETTINGS",
                "setting_TAGS"
        };

        for (String id : checkBox) {

            copy.enableCheckbox(id);

        }

        copy.ClickCopy();
    }
}