package com.mypc.automation.roomtestcase;

import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.roomtools.*;
import com.mypc.automation.pages.utils.ConfigReader;

public class RoomBookingTestCase  extends BaseTest{

	ConfigReader config = new ConfigReader();
	

	@Test
	
	public void verifyRoomBooking( ) {
		
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		loginPage.enterPassword(config.getPassword());
		loginPage.clickLogin();
		
		
		// method 
		
		Room_BookingPage  bookingPage = new Room_BookingPage(driver);
		
		bookingPage.clickAdmin();
		bookingPage.clickTools();
		bookingPage.clickRooms();
		bookingPage.clickBookingRules();
		bookingPage.clickAddNew();
		bookingPage.selectUserTag("Automation Tags");
		bookingPage.selectRoomTag("Automation");
		bookingPage.clickContinue();
		
	}
}
