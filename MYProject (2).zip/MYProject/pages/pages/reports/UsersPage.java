package com.mypc.automation.pages.pages.reports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.mypc.automation.pages.pages.BasePage;

public class UsersPage extends BasePage {

	public UsersPage(WebDriver driver){
		
		super(driver);
	}
	

// locators 
	
// Users report 
	
private By Report=
        By.xpath("//span[normalize-space()='Reports']");


private By UserReport=

        By.xpath("//span[normalize-space()='User Reports']");

private By Location =
        By.xpath("//select[@id='selectedLocationId']");


private By Month =
        By.cssSelector("#period");


private By BookingType = 
        By.id("bookingType");


private By PieChart = 
        By.xpath("//body//app-root//button[2]");


// methods 


public void ClickReport() {
	  wait.until(ExpectedConditions.elementToBeClickable(Report)).click();
}

public void ClickUserReport() {
	
	  wait.until(ExpectedConditions.elementToBeClickable(UserReport)).click();
}

public void SelectLocation(String value) {
	 WebElement dropdown1 = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(Location));
	
	Select select = new Select(dropdown1);
	
	select.selectByVisibleText(value);
		
}

public void SelectMonth(String value) {
	
	 WebElement dropdown2 = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(Month));
	
	 Select select = new Select(dropdown2);
	 
	 select.selectByVisibleText(value);
	
}

public void SelectBookingType(String value) {
	
	 WebElement dropdown3 = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(BookingType));
	Select select = new Select(dropdown3);
	
	select.selectByVisibleText(value);
	
}

public void ClickPieChart() {
	
	  wait.until(ExpectedConditions.elementToBeClickable(PieChart)).click();
	}
}
		

