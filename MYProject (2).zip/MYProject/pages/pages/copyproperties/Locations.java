package com.mypc.automation.pages.pages.copyproperties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.mypc.automation.pages.pages.BasePage;

public class Locations extends BasePage {

    public Locations(WebDriver driver) {
        super(driver);
    }

    // Locators

    private By admin =
            By.xpath("//span[normalize-space()='Admin']");

    private By tools =
            By.xpath("//span[normalize-space()='Tools']");

    private By locationTools =
            By.xpath("//button[normalize-space()='Location Tools']");

    private By copyProperties =
            By.cssSelector("div[class='collapse show'] button[type='button']");

    private By sourceLocation =
            By.name("sourceId");

    private By copyButton =
            By.xpath("//button[contains(@class,'btn-main')]");

    // Methods

    public void clickAdmin() {

        wait.until(ExpectedConditions.elementToBeClickable(admin)).click();
    }

    public void clickTools() {

        wait.until(ExpectedConditions.elementToBeClickable(tools)).click();
    }

    
    public void clickLocations() {

        WebElement element = wait.until(
                ExpectedConditions.visibilityOfElementLocated(locationTools));

        JavascriptExecutor js = (JavascriptExecutor) driver;

        js.executeScript("arguments[0].scrollIntoView(true);", element);
        js.executeScript("arguments[0].click();", element);
    }

    public void clickCopyProperties() {

        WebElement element = wait.until(
                ExpectedConditions.visibilityOfElementLocated(copyProperties));

        JavascriptExecutor js = (JavascriptExecutor) driver;

        js.executeScript("arguments[0].scrollIntoView({block:'center'});", element);

        js.executeScript("arguments[0].click();", element);
    }
   
    

    public void selectLocation(String locationName) {

        WebElement dropdown =
                wait.until(ExpectedConditions.visibilityOfElementLocated(sourceLocation));

        Select select = new Select(dropdown);

        select.selectByVisibleText(locationName);
    }

    public void enableCheckbox(String id) {

        By locator = By.id(id);

        WebElement checkbox =
                wait.until(ExpectedConditions.elementToBeClickable(locator));

        if (!checkbox.isSelected()) {
            checkbox.click();
        }
    }

    public void clickCopy() {

        wait.until(ExpectedConditions.elementToBeClickable(copyButton)).click();
    }
}