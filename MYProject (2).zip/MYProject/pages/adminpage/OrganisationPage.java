package com.mypc.automation.pages.adminpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.mypc.automation.pages.pages.BasePage;


public class OrganisationPage extends BasePage {

	public OrganisationPage(WebDriver driver) {
		super(driver);
		
	}


// locators 
	 // here we need to write alll the main main things in the adminpage of java 
	
private	By adminMenu = By.xpath("//span[contains(text(),'Admin')]");

private By organisation =By.xpath("//span[normalize-space()='Organization']");
private By timeZone = By.xpath("//app-time-zone-selector//select");

private By advancedOption = By.xpath("//button[normalize-space()='advanced options']");

private	By submitButton = By.cssSelector("button[type='submit']");

private By validationMessage = By.xpath("//p[@class='message-dialog']");
	

// methods 
	public void clickAdminMenu() {
		 wait.until(ExpectedConditions.elementToBeClickable(adminMenu)).click();
	}

 
// organisation 
	
	public void clickOrganisation() {
	
		 wait.until(ExpectedConditions.elementToBeClickable(organisation)).click();
	}
		
	

// Time Zone 
	
public void selectTimeZone(String value) {
	
	Select select = new Select(getElement (timeZone));
	select.selectByVisibleText(value);
	
}


public boolean  isTimeZoneDisplayed() {
	
	return isDisplayed (timeZone);
	
	
}
// Advanced Option 

public void clickAdvancedOption() {
	
	click(advancedOption);
}



// check box 


public void enableCheckBox(String id) {
	
	By locator = By.id(id);
	
	if(!getElement(locator).isSelected()) {
		
		click(locator);
	}

	}



// negative scenario 


public void disableCheckbox(String id ) {
	
	By locator = By.id(id);
	
if(getElement(locator).isSelected()) {
	
	click(locator);
	
	
}
}


// creating method for the disable 

public void disableAllUser() {
disableCheckbox ("allowAuthRezzervi");
disableCheckbox("allowAuthGoogle");
disableCheckbox("allowAuthMicrosoft");
disableCheckbox("allowAuthEntraID");
disableCheckbox("allowAuthITSDS");

}

// Submit button 

public void clickSubmit() {
	
	click(submitButton);
	
}


	public boolean isDisplayedSubmit() {
		
		return isDisplayed(submitButton);
	
}

// Assertation 
	
	public String getValidationMessage() {

	    wait.until(ExpectedConditions.visibilityOfElementLocated(validationMessage));

	    return getElement(validationMessage).getText().trim();
	}
	

public String getInvalidMessage() {
	
	wait.until(ExpectedConditions.visibilityOfElementLocated(validationMessage));
	
	return getElement(validationMessage).getText().trim();
}
	}









