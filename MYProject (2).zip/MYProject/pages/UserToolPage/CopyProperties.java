package com.mypc.automation.pages.UserToolPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.mypc.automation.pages.pages.BasePage;

public class CopyProperties extends BasePage {

    public CopyProperties(WebDriver driver) {
        super(driver);
    }

    // Locators

    private By admin =
            By.xpath("//span[contains(text(),'Admin')]");

    private By tools =
            By.xpath("//span[normalize-space()='Tools']");
    
    private By Users = By.xpath("//button[normalize-space()='User Tools']");
    
    private By CopyProperties = By.xpath("//button[normalize-space()='Copy Properties']");
    		

    private By Tag =
            By.id("tag_b28410dd-7332-42f6-9863-019f501d4b97");

    private By userRole =
            By.id("setting_USER_ROLE");

    private By settingTags =
            By.id("setting_TAGS");

    private By copy =
            By.xpath("//button[@class='btn btn-main btn-form']");

    // Methods

    public void clickAdmin() {
        wait.until(ExpectedConditions.elementToBeClickable(admin)).click();
    }

    public void clickTools() {
        wait.until(ExpectedConditions.elementToBeClickable(tools)).click();
        
    } 
    public void ClickUsers() {
    	
    	  wait.until(ExpectedConditions.elementToBeClickable(Users)).click();
          
    }
    

  
 public void ClickCopyProperties() {
	 
	  wait.until(ExpectedConditions.elementToBeClickable(CopyProperties)).click(); 
	  
 }
    public void enableCheckbox(String id) {

        By locator = By.id(id);

        WebElement element = wait.until(
                ExpectedConditions.elementToBeClickable(locator));

        
        if(!getElement(locator).isSelected()) {
    		
    		click(locator);
        }
    }

    public void clickCopy() {
        wait.until(ExpectedConditions.elementToBeClickable(copy)).click();
    }
}