package com.mypc.automation.computertestcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.computers.*;

import com.mypc.automation.pages.utils.ConfigReader;
public class DeskProfileTestCase extends  BaseTest {

	
	ConfigReader config = new ConfigReader();
	
	@Test
	
	public void verifyAddDesk() {
		
		
		// creating construtor for loginPage
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		
		loginPage.enterPassword(config.getPassword());
		
		loginPage.clickLogin();
		
		// creating constructor for DeskProfile 
		
		DeskProfile Deskp = new DeskProfile(driver);
		
		Deskp.ClickAdmin();
		Deskp.ClickTools();
		Deskp.Clickcomputers();
		Deskp.Clickdeskprofile();
		Deskp.ClickAddnew();
		Deskp.SelectUsertags(config.getUsersTag());
		
		Assert.assertTrue(Deskp.isDisplayed(), "User Tags is not displayed");
		
		Deskp.SelectComputerstags(config.getComputerTags());
		
		Assert.assertTrue(Deskp.isComputerDisplayed(),"Computer Tags is not displayed");
		
		Deskp.ClickSubmit();
		
		Assert.assertTrue(Deskp.isContinueDisplayed(),"Continue is not displayed");
				
		
		Deskp.enternameContext(config.getContext());
		
		Deskp.enternameUsername(config.getUsername());
		
		Deskp.enternamePassword(config.getPassword1());
		
		Deskp.ClickSubmit();
	}
}
