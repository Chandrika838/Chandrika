package com.mypc.automation.computertestcase;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.computers.Computerstags;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.computers.*;
import com.mypc.automation.pages.utils.ConfigReader;

import org.testng.Assert;
import org.testng.annotations.Test;

public class computertags extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyAddComputers() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        // Computer Tags
        Computerstags comp = new Computerstags(driver);

        comp.clickAdmin();
        comp.clickTools();
        comp.clickComputerTools();
        comp.ClickTags();
        comp.ClickAddNew();

        String tagName = config.getComputerTags();

        System.out.println("Tag Name = " + tagName);

        comp.enterComputerTags(tagName);

        comp.clickAdd();
  
    
    Assert.assertTrue(comp.isDisplayedSubmit(),"Submit is not Displayed");
    
    }
    
}