package com.mypc.automation.desktestcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.desktools.DeskBookingRules;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.utils.ConfigReader;

public class DeskBookingRulesTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyAddDesk() {

  // Creating a constructor for loginpage 
    	
  
 LoginPage loginPage = new LoginPage(driver);
 
 loginPage.enterEmail(config.getEmail());
 
 loginPage.enterPassword(config.getPassword());
 
 loginPage.clickLogin();
 
 
 // creating a constructor for the booking rules 
 
 
 DeskBookingRules desk = new DeskBookingRules(driver);
 
 desk.clickAdmin();
 
 desk.clickTools();
 
 desk.ClickDesk();
 
 desk.ClickBookingRules();
 
 desk.ClickDeskPage();
 
 desk.clickAccess();
 
 
 Assert.assertTrue(desk.isAccessSelected(), "Access is not Selected");
 
 desk.ClickMaximumPerMonth();
 
 Assert.assertTrue(desk.isMaximumPerMonthSelected(), "Maximum Per Month Selected ");
 
desk.ClickMaxiumBookingDuration();

Assert.assertTrue(desk.isSelectedMaxiumBookingDuration(), "Maximum Booking is not selected");

desk.ClickBookingPerDay();


Assert.assertTrue(desk.isSelectedBookingPerDay(),"Booking Per Day is not Selected ");



desk.ClickMaximumAllowedPerDay();


Assert.assertTrue(desk.isSelectedMaxiumAllowedPPerDay(),"Booking Per Day is not Selected");


desk.ClickMaxiumperiodAdvance();


Assert.assertTrue(desk.isSelectedMaxiumperiodAdvance(), "Maxium period Advance is not Selected");


desk.ClickSubmit();
 
 
 
 Assert.assertTrue(desk.isSubmitDisplayed(), "Submit is not Displayed ");
 
 
 
 
 
 
 
 
    }
    
}