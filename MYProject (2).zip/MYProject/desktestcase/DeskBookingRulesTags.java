package com.mypc.automation.desktestcase;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.desktools.DeskBookingRulestags;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.desktools.DeskBookingRulestags;
import com.mypc.automation.pages.utils.ConfigReader;

public class DeskBookingRulesTags extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyDeskBookingRulesTags() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        // Create Page Object
        DeskBookingRulestags desk = new DeskBookingRulestags(driver);

        // Navigation
        desk.ClickAdmin();
        desk.ClickTools();
        desk.ClickDesk();
        desk.ClickTags();
        desk.ClickTool();
        desk.ClickBookingRules();

        // Add Booking Rule Tag
        desk.ClickAddNew();
        Assert.assertTrue(desk.isDisplayedAddNew(), "Add New button is not displayed");

        desk.SelectID("Automation Tags");

        desk.ClickContinue();
        Assert.assertTrue(desk.isDisplayedContinue(), "Continue button is not displayed");

        desk.ClickUpdate();
        Assert.assertTrue(desk.isDisplayedUpdate(), "Update button is not displayed");

        desk.ClickUpdate1();
        Assert.assertTrue(desk.isDisplayedUpdate1(), "Final Update button is not displayed");
    }
}
	

