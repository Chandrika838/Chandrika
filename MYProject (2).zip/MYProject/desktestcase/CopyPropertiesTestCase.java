package com.mypc.automation.desktestcase;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.desktools.CopyProperites;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.pages.copyproperties.*;
import com.mypc.automation.pages.utils.ConfigReader;

import org.testng.annotations.Test;

public class CopyPropertiesTestCase  extends BaseTest{

	ConfigReader config =new ConfigReader();
	
	@Test
	
	public void verifyDesk() {
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		
		loginPage.enterPassword(config.getPassword());
		
		loginPage.clickLogin();
		
		
	// methods 
		
	CopyProperites Desk =new CopyProperites(driver);
	
	Desk.ClickAdmin();
	Desk.ClickTools();
	Desk.ClickDesk();
	Desk.ClickCopyProperties();
	Desk.SelectSource(config.getDeskName());
	Desk.SelectLocation(config.getLocation());
	
	// Authenatication checkobx 
	
	String[] CheckBox ={
		
		"tag_c95219e7-b1aa-4b2b-9efb-019f5c11cb30",
		"setting_LOCATION",
		"setting_DEFAULT_DURATION",
		"setting_PREPARATION_TIME",
		"setting_CHECK_IN_SETTINGS",
		"setting_TAGS",
		
	};
	
	for(String id : CheckBox) {
		
		Desk.enableCheckbox(id);
	}
	
		
		
	Desk.ClickCopy();	
		
		
		
	}
}
