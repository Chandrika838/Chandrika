package com.mypc.automation.desktestcase;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.pages.LoginPage;
import com.mypc.automation.pages.desktools.Desk_Tags;
import com.mypc.automation.pages.utils.ConfigReader;

import org.testng.Assert;
import org.testng.annotations.Test;

public class DeskTags_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();


    @Test
    public void verifyDeskTags() {

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.enableHighContrast();
        loginPage.clickLogin();

        Desk_Tags deskTags = new Desk_Tags(driver);

        deskTags.ClickAdmin();
        deskTags.ClickTools();
        deskTags.ClickDesk();
        deskTags.ClickTags();
        deskTags.ClickAddNew();

        String tagName = config.getDeskTagName();

        System.out.println("Tag Name = " + tagName);

        deskTags.enterDeskTags(tagName);

        deskTags.clickAdd();
   
    Assert.assertTrue(deskTags.isDisplayedSubmit(), "Submit is not Displayed");
    
    
    
    
    }
    
    
}