package BookingRulesTags;

import org.testng.Assert;
import org.testng.annotations.Test;

import POM.BaseTest;
import POM.LoginPage;
import Utilities.ConfigReader;

public class UsersTestCase extends BaseTest{

	
	ConfigReader config = new ConfigReader();
	
	@Test
	
	public void VerifyAddUserTestCase() {
		
		
	
		LoginPage loginPage = new LoginPage(driver);

		loginPage.enterEmail(config.getEmail());
		loginPage.enterPassword(config.getPassword());

		loginPage.clickLogin();


		// creating the constructor for the Room Test case


		Userspage users = new Userspage(driver); 
			
		users.ClickAdmin();

		users.ClickTools();
		users.ClickUsers();
		users.ClickTags();

		users.ClickTool();

		users.ClickBookingRules();
		
        users.ClickBookingRules1();
        
        users.ClickBookingRules2();
        
        users.ClickBookingRules3();
	
		users.ClickUpdate();

		Assert.assertTrue(users.isDisplayedUpdate(),"Update is not Displayed");

		
		}
			}


