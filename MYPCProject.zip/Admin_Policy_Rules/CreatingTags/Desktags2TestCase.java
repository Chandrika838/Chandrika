package CreatingTags;

import org.testng.annotations.Test;

import POM.BaseTest;
import POM.LoginPage;
import Utilities.ConfigReader;

public class Desktags2TestCase  extends BaseTest{
	
	private final ConfigReader config = new ConfigReader();

    @Test
    public void verifyDeskTags() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        // Desk Tags page
        Desk_Tags deskTags2 = new Desk_Tags(driver);

        
        Desktags2 desk = new Desktags2(driver);

        desk.clickAdmin();
        desk.clickTools();
        desk.clickDesk();
        desk.clickTags();
        desk.clickAddNew();
        desk.selectChandrikuserTags();
        desk.clickContinue();
    }
}



