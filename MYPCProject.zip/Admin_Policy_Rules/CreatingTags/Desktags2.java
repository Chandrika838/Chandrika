package CreatingTags;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import POM.BasePage;

public class Desktags2 extends BasePage {

    public Desktags2(WebDriver driver) {
        super(driver);
    }

    // ===========================
    // Locators
    // ===========================

    private By admin =
            By.xpath("//span[normalize-space()='Admin']");

    private By tools =
            By.xpath("//span[normalize-space()='Tools']");

    private By desk =
            By.xpath("//button[normalize-space()='Desk Tools']");

    private By tags =
            By.cssSelector("div[class='collapse show'] button:nth-child(3)");

    private By addNewButton =
            By.xpath("//button[normalize-space()='Add New']");

    private By userTagDropdown =
            By.id("userTagId");

    private By continueButton =
            By.xpath("//button[.//span[normalize-space()='Continue']]");

    // ===========================
    // Methods
    // ===========================

    public void clickAdmin() {

        wait.until(ExpectedConditions.elementToBeClickable(admin)).click();
    }

    public void clickTools() {

        wait.until(ExpectedConditions.elementToBeClickable(tools)).click();
    }

    public void clickDesk() {

        wait.until(ExpectedConditions.elementToBeClickable(desk)).click();
    }

    public void clickTags() {

        wait.until(ExpectedConditions.elementToBeClickable(tags)).click();
    }

    public void clickAddNew() {

        WebElement addButton = wait.until(
                ExpectedConditions.elementToBeClickable(addNewButton));

        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].click();", addButton);
    }

    public void selectChandrikuserTags() {

        WebElement dropdown = wait.until(
                ExpectedConditions.visibilityOfElementLocated(userTagDropdown));

        Select select = new Select(dropdown);

        select.selectByVisibleText("Chandrika user Tags");
    }

    public void clickContinue() {

        WebElement button = wait.until(
                ExpectedConditions.elementToBeClickable(continueButton));

        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView({block:'center'});", button);

        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].click();", button);
    }
}