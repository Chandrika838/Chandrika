package CreatingTags;

import org.testng.Assert;
import org.testng.annotations.Test;

import POM.BaseTest;
import POM.LoginPage;
import Utilities.ConfigReader;

public class UserTagsTestCase extends BaseTest{
	
	ConfigReader config = new ConfigReader();
	
	@Test
	
 public void verifyAddUserTestCase() {
		
	
		LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.enableHighContrast();
        loginPage.clickLogin();

        UsersTags Users = new UsersTags(driver);

        Users.ClickAdmin();
        Users.ClickTools();
        Users.ClickUsersTool();
        Users.ClickTags();
        Users.ClickAddNew();

        String tagName = config.getUsersTag();

        System.out.println("Tag Name = " + tagName);

        Users.enterUsersTag(tagName);

        Users.clickAdd();
      
        
        Assert.assertTrue(Users.isDisplayedAddSubmit(), "Submit is not Displayed");
        
    }
  
	}




