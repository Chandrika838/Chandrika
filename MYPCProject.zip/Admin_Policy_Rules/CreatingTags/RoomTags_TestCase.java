package CreatingTags;

import org.testng.Assert;
import org.testng.annotations.Test;

import POM.BaseTest;
import POM.LoginPage;
import Utilities.ConfigReader;

public class RoomTags_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyRoomTags() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        // Room Tags
        RoomTags roomTags = new RoomTags(driver);

        roomTags.ClickAdmin();
        roomTags.ClickTools();
        roomTags.ClickRoom();
        roomTags.ClickTags();
        roomTags.ClickAddNew();

        String tagName = config.getRoomTags();

        System.out.println("Tag Name = " + tagName);

       roomTags.enterRoomTags(tagName);

        roomTags.clickAdd();
    }
    

       
    }

