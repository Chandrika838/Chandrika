package CreatingTags;

import org.testng.Assert;
import org.testng.annotations.Test;

import POM.BaseTest;
import POM.LoginPage;
import Utilities.ConfigReader;

public class ComputerTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyAddComputers() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.clickLogin();

        // Computer Tags
        Computers comp = new Computers(driver);

        comp.clickAdmin();
        comp.clickTools();
        comp.clickComputerTools();
        comp.ClickTags();
        comp.ClickAddNew();

        String tagName = config.getComputerTags();

        System.out.println("Tag Name = " + tagName);

        comp.enterComputerTags(tagName);

        comp.clickAdd();
  
    
    Assert.assertTrue(comp.isDisplayedSubmit(),"Submit is not Displayed");
    
    }
    
}