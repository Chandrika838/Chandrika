package UsersBooking;

import org.testng.Assert;
import org.testng.annotations.Test;

import POM.BaseTest;
import POM.LoginPage;
import Utilities.ConfigReader;

public class UsersTestCase extends BaseTest{

	ConfigReader config = new ConfigReader();
	
	@Test
	
	public void VerifyAddUser() {
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		
		loginPage.enterPassword(config.getPassword());
		
		loginPage.clickLogin();
		
		
		
	
	
	RoomPage Users = new RoomPage(driver);
	
	Users.ClickAdmin();
	Users.ClickTools();
	Users.ClicUser();
	Users.ClickBookingRules();
	Users.ClickRooms();
	Users.ClickAllusers();
	Users.ClickAccess();
	
	Assert.assertTrue(Users.isAccessSelected(), "Access is Not Selected");
	
	Users.enablemaxiumBookingPerMonth("1000");
	
	Assert.assertTrue(Users.isMaxiumBookingperMonthDisplayed(),"Maxium Booking per Month is Displayed");
	
	Users.enablemaxiumByDuration("20");
	
	Assert.assertTrue(Users.isMaxiumByDurationDisplayed(), "Maxium By Duration is not Displayed");
	
	Users.enableNumberofbooking("10");
	
	Assert.assertTrue(Users.isNumberofBookingDisplayed(), "Number of Booking is Displayed");
	
	Users.enableMaximumallowedperday("4");
	
	Assert.assertTrue(Users.MaxiumallowedperdayDisplayed(),"Maximum allwed per day");
	
	Users.enableMaximunPeriodadvance("1450");
	Users.ClickcanMake();
	
	Assert.assertTrue(Users.isSelectedCanMake() , "Can Make is Dsiplayed");
	
	Users.enableMaxmium("3");
	
	Users.ClickCancel();
	
	Users.ClickSubmit();
	
	
	
	}
	
}
