package BookingRulesTestCase;

import org.testng.Assert;
import org.testng.annotations.Test;

import BookingRules.RoomPage;
import POM.BaseTest;
import POM.LoginPage;
import Utilities.ConfigReader;

public class RoomTestCase  extends BaseTest{

	
	ConfigReader config = new ConfigReader();
	
	@Test
	public void verifyAddRoomTest() {

	    LoginPage loginPage = new LoginPage(driver);

	    loginPage.enterEmail(config.getEmail());
	    loginPage.enterPassword(config.getPassword());
	    loginPage.clickLogin();

	    RoomPage room = new RoomPage(driver);

	    room.clickAdmin();
	    room.clickTools();
	    room.clickRooms();
	    room.clickBookingRules();
	    room.ClickRoomPage();

	    room.clickAccess();
	    room.ClickToogle();

	    room.ClickMaximumPerMonth();
	    room.enableToogle1("2");

	    room.ClickMaxiumBookingDuration();
	    room.enableToogle2("3");

	    room.ClickBookingPerDay();
	    room.enableToogle3("2");

	    room.ClickMaximumAllowedPerDay();
	    room.enableToogle4("3");

	    room.ClickMaxiumperiodAdvance();
	    room.enableToogle5("4");

	    room.ClickSubmit();

	   
	    String actualMessage = room.getSuccessMessage();

	    Assert.assertEquals(
	            actualMessage,
	            "Booking Rules Updated Successfully",
	            "Booking Rules were not updated successfully.");
	}
	
}
