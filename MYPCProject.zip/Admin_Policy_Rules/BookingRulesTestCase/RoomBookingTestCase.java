package BookingRulesTestCase;

import org.testng.annotations.Test;

import BookingRules.Room_BookingPage;
import POM.BaseTest;
import POM.LoginPage;
import Utilities.ConfigReader;

public class RoomBookingTestCase  extends BaseTest{

	ConfigReader config = new ConfigReader();
	

	@Test
	
	public void verifyRoomBooking( ) {
		
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		loginPage.enterPassword(config.getPassword());
		loginPage.clickLogin();
		
		
		// method 
		
		Room_BookingPage  bookingPage = new Room_BookingPage(driver);
		
		bookingPage.clickAdmin();
		bookingPage.clickTools();
		bookingPage.clickRooms();
		bookingPage.clickBookingRules();
		bookingPage.clickAddNew();
		bookingPage.selectUserTag("Automation Tags");
		bookingPage.selectRoomTag("Automation");
		bookingPage.clickContinue();
		
	}
}
