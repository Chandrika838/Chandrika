package BookingRulesTestCase;

import org.testng.Assert;
import org.testng.annotations.Test;

import BookingRules.DeskPage;
import POM.BaseTest;
import POM.LoginPage;
import Utilities.ConfigReader;

public class DeskTestCase extends BaseTest {

	ConfigReader config = new ConfigReader();
	
	@Test
	
	public void verifyAddDesk() {
		
		// Creating a constructor for login page 
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		loginPage.enterPassword(config.getPassword());
		loginPage.clickLogin();
		
		
		
		// creating a constructor for deskpage
		
		DeskPage Desk = new DeskPage(driver);
		
		Desk.clickAdmin();
		
		Desk.clickTools();
		
		Desk.ClickDesk();
		
		Desk.ClickBookingRules();
		
		Desk.ClickDeskPage();
		
		Desk.clickAccess();
		
		
		
		Desk.ClickToogle();
		
		Desk.ClickMaximumPerMonth();
		
		Desk.enableToogle1("1");
		
		Desk.ClickMaxiumBookingDuration();
		
		Assert.assertTrue(Desk.isSelectedMaxiumBookingDuration(),"Maxium Booking Duration is not Seleted ");
		
		Desk.enableToogle2("3");
		
		Desk.ClickBookingPerDay();
		
		Assert.assertTrue(Desk.isSelectedBookingPerDay(), "Booking per Day ");
		
		Desk.enableToogle3("2");
		
		Desk.ClickMaximumAllowedPerDay();
		
		Assert.assertTrue(Desk.isSelectedMaxiumAllowedPPerDay(), "maxium Allowed Per Day ");
		
		Desk.enableToogle4("4");
		
		Desk.ClickMaxiumperiodAdvance();
		
		Assert.assertTrue(Desk.isSelected(), "Maxium period Advance ");
		Desk.enableToogle5("5");
		
		
		Assert.assertTrue(Desk.isSubmitDisplayed(), "Submit is not Displayed ");
		
		Desk.ClickSubmit();
		
	}
}
