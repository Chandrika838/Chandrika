package POM;

import org.testng.Assert;
import org.testng.annotations.Test;

import Utilities.ConfigReader;

public class Reserve_Room_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyReserveRoom() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(config.getEmail(), config.getPassword());

        // Reserve Room Page
        Reserve_RoomPage reserve = new Reserve_RoomPage(driver);

        reserve.clickReserve();

        reserve.clickRoom();

        reserve.selectLocation(config.getLocation());
        
        Assert.assertTrue(reserve.isDisplayedLocation(), "Location is not Selected ");
        
        
        reserve.selectDate("Aug 2026", "5");
        

        reserve.clickToolTip();

        reserve.selectStartime(config.getstartTime());

        reserve.clickDragdrop();

        reserve.enableSelfBooking();

        reserve.clickSubmit();
    }
}