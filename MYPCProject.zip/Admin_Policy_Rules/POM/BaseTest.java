package POM;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseTest {

	protected WebDriver driver;
	
@BeforeMethod

public void setup() {
	
 driver = new ChromeDriver();
	 
driver.manage().window().maximize();

driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(40));
	 
	 
driver.get("https://rezzqa6.its-cs.com/Auth/Login?returnUrl=%2FDashboard");
 }

 @AfterMethod
 public void tearDown() {

     if (driver != null) {
         driver.quit();
     }
 }
}	 
	 
	 
	 
	 
 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 

 

