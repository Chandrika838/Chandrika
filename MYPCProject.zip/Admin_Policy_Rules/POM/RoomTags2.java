package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class RoomTags2 extends BasePage{

	public RoomTags2(WebDriver driver) {
		
		super(driver);
	}


	private By admin =
	        By.xpath("//span[normalize-space()='Admin']");

	private By tools = 
	        By.xpath("//span[normalize-space()='Tools']");
		
	private By roomTools = 
	        By.xpath("//button[normalize-space()='Room Tools']");
	
	
	private final By tagsButton =
            By.xpath(
            		 "//button[normalize-space()='Tags']");
	
	 
	//click on add button
    private final By addNewButton =
            By.cssSelector("button[class='link-button']");
 
    private final By tagNameInput =
            By.cssSelector("input[formcontrolname='name']");

    
    private final By Submit = 
    		By.cssSelector("button[type='submit']");

    
  // Methods
    
    
    public void clickAdmin() {
    	
    	wait.until(ExpectedConditions.elementToBeClickable(admin)).click();
    	
    }
    
   
    public void clickTools() {
    	
    	wait.until(ExpectedConditions.elementToBeClickable(tools)).click();
    	
    }
    
    
    public void ClickRoomsTools() {
    	wait.until(ExpectedConditions.elementToBeClickable(roomTools)).click();
    	
    }
    
    
    public void ClickTags() {
    
    	    WebElement element = wait.until(
    	            ExpectedConditions.visibilityOfElementLocated(tagsButton));

    	    ((JavascriptExecutor) driver)
    	            .executeScript("arguments[0].click();", element);
    	}
    
    
    public void ClickAddNew() {

        WebElement element = wait.until(
                ExpectedConditions.visibilityOfElementLocated(addNewButton));

        JavascriptExecutor js = (JavascriptExecutor) driver;

        js.executeScript("arguments[0].scrollIntoView({block:'center'});", element);
        js.executeScript("arguments[0].click();", element);
    }
    
    
    
    public void enterTagName(String value) {

        WebElement element = wait.until(
                ExpectedConditions.visibilityOfElementLocated(tagNameInput));

        JavascriptExecutor js = (JavascriptExecutor) driver;

        js.executeScript("arguments[0].scrollIntoView({block:'center'});", element);
        js.executeScript("arguments[0].value = arguments[1];", element, value);
    }

    
     public void ClickSubmit() {       
    
    		wait.until(ExpectedConditions.elementToBeClickable(Submit)).click();
        	
    	 

     }
		
	}
    



   
