package POM;

import org.testng.annotations.Test;

import Utilities.ConfigReader;

public class Tags_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyAddTags() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(config.getEmail(), config.getPassword());

        // Tags Page
        Tags tagsPage = new Tags(driver);

        tagsPage.ClickAdmin();

        tagsPage.ClickTools();

        tagsPage.ClickUsers();

        tagsPage.ClickTags();

        tagsPage.ClickUserName();

        tagsPage.enterUserTag("Automation Tags");

        // Enable checkbox if required
        // tagsPage.enableCheckbox();

        tagsPage.ClickbookingRules();

        // Click Add New if required
        // tagsPage.ClickAddnew();

        // Click Automation if required
        // tagsPage.ClickAutomation();

        tagsPage.selectPleaseChoose(config.getPleasechoose());

        tagsPage.ClickSubmit();
    }
}