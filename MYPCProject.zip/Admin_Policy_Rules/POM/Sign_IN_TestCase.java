package POM;

import org.testng.Assert;
import org.testng.annotations.Test;

import TestCase_MYPC.Sign_In;
import Utilities.ConfigReader;


public class Sign_IN_TestCase extends BaseTest{

	
	 ConfigReader config = new ConfigReader();
	
	@Test
	
	public void verifySignIn() {
		
	// creating an object 
		
	
// creating a constructor for LoginPage 
		
	LoginPage loginPage = new LoginPage(driver);
	
	loginPage.enterEmail(config.getEmail());
	
	loginPage.enterPassword(config.getPassword());
	
	loginPage.clickLogin();
	
	
	// creating a constructor for SingIn Page 
	
	
	Sign_INPage sign = new Sign_INPage(driver);
	
		sign.clickProfile();
		
		Assert.assertTrue(sign.isSettingDisplayed(), "Setting is not Displayed ");
		
		sign.ClickSetting();
		
		
		
		sign.selectTheme(config.getTheme());
		
		Assert.assertTrue(sign.isDisplayedTheme(), "theme is not Displayed ");
		
		sign.SelectLanguage(config.getlanguage());
		
	
		
		sign.SelectZom(config.getZoom());
		
		sign.clickSubmit();
		
		Assert.assertTrue(sign.isDisplayedSubmit(), "submit is not Displayed ");
			
		
	}
	
}