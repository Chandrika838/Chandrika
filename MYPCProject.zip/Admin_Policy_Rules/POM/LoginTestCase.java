package POM;

import org.testng.Assert;
import org.testng.annotations.Test;

import Utilities.ConfigReader;

public class LoginTestCase extends BaseTest {
	
	ConfigReader config = new ConfigReader();


	@Test
	public void verifyValidLogin() {

		LoginPage loginPage = new LoginPage(driver);

	    loginPage.enterEmail(config.getEmail());

	    loginPage.enterPassword(config.getPassword());

	   
	    loginPage.enableHighContrast();
	    
	    Assert.assertTrue(loginPage.isHighContrastEnabled(), "Enable is not High Constrast");

	   
	    loginPage.clickLogin();
	    
	    Assert.assertTrue(loginPage.isDisplayedLogin(),"Login page is not Displayed ");

	    // Verify next page here
	
	}
	}