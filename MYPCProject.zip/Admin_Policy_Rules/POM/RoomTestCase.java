package POM;

import org.testng.Assert;
import org.testng.annotations.Test;

import Utilities.ConfigReader;

public class RoomTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyAddRoom() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(config.getEmail(), config.getPassword());

        // Room Page
        RoomPage room = new RoomPage(driver);

        // Verify Admin
        Assert.assertTrue(room.isAdminDispalyed(),
                "Admin is not displayed");

        room.ClickAdmin();

        // Verify Room Menu
        Assert.assertTrue(room.isRoomDisplayed(),
                "Room is not displayed");

        room.ClickRoom();

        // Verify Add New Button
        Assert.assertTrue(room.isAddNewDisplayed(),
                "Add New button is not displayed");

        room.ClickAddNew();

        // Verify Room Name Field
        Assert.assertTrue(room.isRoomNameDisplayed(),
                "Room Name field is not displayed");

        room.enterRoomName(config.getroomName());

        // Verify Location
        Assert.assertTrue(room.isLocationDisplayed(),
                "Location dropdown is not displayed");

        room.selectLocation(config.getLocation());

        // Advanced Options
        room.ClickAdvanceOption1();

        // Verify Preparation
        Assert.assertTrue(room.isPrepartionDisplayed(),
                "Preparation dropdown is not displayed");

        room.selectPrepartion(config.getPrepration());

        // Verify Submit Button
        Assert.assertTrue(room.isSubmitDisplayed(),
                "Submit button is not displayed");

        room.clickSubmit();
    }
}