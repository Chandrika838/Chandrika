package POM;

import org.testng.Assert;
import org.testng.annotations.Test;

import Utilities.ConfigReader;

public class LocationTestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyAddLocation() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(config.getEmail(), config.getPassword());

        // Location Page
        Location locationPage = new Location(driver);

        // Verify and click Admin
        Assert.assertTrue(locationPage.isAdminDisplayed(),
                "Admin is not displayed");

        locationPage.clickAdmin();

        // Verify and click Location
        Assert.assertTrue(locationPage.isLocationDisplayed(),
                "Location is not displayed");

        locationPage.clickLocation();

        // Click Add New
        locationPage.clickAddNew();

        // Enter Location Name
        locationPage.enterLocatioName(config.getLocation());

        // Click Advanced Options
        locationPage.clickAdvancedOptions();
        
        locationPage.SelectParentLocation(config.getparentLocation());
        
        locationPage.SelectTimeZone(config.gettimeZone());

        // Submit
        locationPage.ClickSubmit();
        
        
        
    }
}