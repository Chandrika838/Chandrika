package POM;

import org.testng.Assert;
import org.testng.annotations.Test;

import Utilities.ConfigReader;

public class Reserve_Computer_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyReserveAdd() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(config.getEmail(), config.getPassword());

        // Reserve Computer Page
        Reserve_Computer_Page reservePage = new Reserve_Computer_Page(driver);

        reservePage.ClickReserve();

        reservePage.ClickComputer();

        reservePage.SelectLocation2(config.getReserveLocation());
        
        Assert.assertTrue(reservePage.isDisplayedLocation(),"Location is not displayed");

        reservePage.selectDate("Aug 2026", "5");
      
    
        reservePage.ClickTooltips();
        
        Assert.assertTrue(reservePage.isDisplayedTooltips(), "Tooltips is not displayed");

        reservePage.SelectStartTime2(config.getStartTime2());
        
        

        reservePage.EnableSelfBookings();
        
        Assert.assertTrue(reservePage.isSelectedSelfBooking(), "Self Booking is not Selected");
        
        
     //   reservePage.Recurrence();
        
       // reservePage.selectBooking(config.getperiods());
        
      //  reservePage.ClickUpdate();

        reservePage.ClickBooks();
        
        Assert.assertTrue(reservePage.isDisplayedBooks(), "Books is not Displayed ");
    }
}