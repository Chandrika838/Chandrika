package POM;

import org.testng.Assert;
import org.testng.annotations.Test;

import Utilities.ConfigReader;

public class GuestUsersTestCase extends BaseTest {

	ConfigReader config = new ConfigReader();
	
	@Test
	
	public void VerifyAddGuestUsers() {
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		
		loginPage.enterPassword(config.getPassword());
		
		loginPage.clickLogin();
		
		// creating an constructor 
		
		GuestUsersPage GuestUsers = new GuestUsersPage(driver);
		
		GuestUsers.ClickAdmin();
		
		GuestUsers.ClickTools();
		
		GuestUsers.ClickUsers();
		
		GuestUsers.ClickGuestUsers();
		
		GuestUsers.ClickAddNew();
		
		GuestUsers.enterName(config.getName());
		
		GuestUsers.enterPrefix(config.getUserprefix());
		
		GuestUsers.enterNumberofFigures(config.getNumberoffigure());
		
		GuestUsers.SelectCharacter("alphanumeric");
		
		GuestUsers.enterLength(config.getLength());
		
		GuestUsers.SelectExpired("hours");
		
		GuestUsers.ClickCheckbox();
		
		Assert.assertTrue(GuestUsers.isSelectedChedckbox(), "CheckBox is not Selected ");
		
		GuestUsers.SelectActivation(config.getActivation());
		
		Assert.assertTrue(GuestUsers.isDisplayedSubmit());
		
		GuestUsers.ClickSubmit();
		
		
	}
}
