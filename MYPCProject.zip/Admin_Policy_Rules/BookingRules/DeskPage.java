package BookingRules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import POM.BasePage;

public class DeskPage extends BasePage {

	public DeskPage(WebDriver driver) {
		
		super(driver);
		
	}
	
	
	// locators 
	
	
	private By admin =
            By.xpath("//span[normalize-space()='Admin']");

    private By tools =
            By.xpath("//span[normalize-space()='Tools']");
    
    private By Desk = 
    		By.xpath("//button[normalize-space()='Desk Tools']");
    
    
    private By BookingRule = 
    		By.cssSelector("div[class='collapse show'] button:nth-child(4)");
    
    private By DeskPage=
    		By.cssSelector("span[title='Automation Tags']");
    
    
    private By Access = 
    		By.id("canAccessIsDefined");
    
    private By Toogle = 
    		By.cssSelector("#canAccess");
    
    private By MaxiumPerMonth = 
    		By.id("maximumNumberOfBookingsPerMonthIsDefined");
    
    private By Toogle1 = 
    		By.id("maximumNumberOfBookingsPerMonth");
    
    private By MaxiumBookingDuration = 
    		By.cssSelector("#maximumBookingDurationIsDefined");
    
    private By Toogle2 = 
    		By.id("maximumBookingDuration");
    
    private By BookingPerDay =
    		By.id("numberOfBookingsPerDayIsDefined");
    
    private By Toogle3=
    		By.id("numberOfBookingsPerDay");
    
    
    private By MaximumAllowedPerDay =
    		By.cssSelector("#maximumTimeAllowedPerDayIsDefined");
    
    private By Toogle4 = 
    		By.id("maximumTimeAllowedPerDay");
    
    private By MaxiumperiodAdvance=
    		By.cssSelector("#maxDaysInAdvanceIsDefined");
    
    private By Toogle5 =
    		By.id("maxDaysInAdvance");
    
    private By Submit = 
 		   By.cssSelector("button[type='submit']");
    
    
    
    
    // methods 
    
    public void clickAdmin() {
        wait.until(ExpectedConditions.elementToBeClickable(admin)).click();
    }

    public void clickTools() {
        wait.until(ExpectedConditions.elementToBeClickable(tools)).click();
    }

    public void ClickDesk() {
        wait.until(ExpectedConditions.elementToBeClickable(Desk)).click();
    }

    public void ClickBookingRules() {
        wait.until(ExpectedConditions.elementToBeClickable(BookingRule)).click();
    }

    		
    public void ClickDeskPage() {
	
	 wait.until(ExpectedConditions.elementToBeClickable(DeskPage)).click();
}
    
   
    public void clickAccess() {

        WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(Access));

        if (!checkbox.isSelected()) {
            checkbox.click();
        }  
   
    }
    
    public void ClickToogle() {
    	
    	

        WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(Toogle));

        if (!checkbox.isSelected()) {
            checkbox.click();
        }  
   
    }
    
    
    public void ClickMaximumPerMonth() {
    	
    WebElement checkbox = wait.until(
            ExpectedConditions.elementToBeClickable(MaxiumPerMonth));

    if (!checkbox.isSelected()) {
        checkbox.click();
    }  

}
    
    
    public void enableToogle1(String value ) {
    	
    	 WebElement textbox = wait.until(
    	            ExpectedConditions.visibilityOfElementLocated(Toogle1));

    	    textbox.clear();          // Removes the existing value

    	    textbox.sendKeys(value); 
    
    }
    
    public void ClickMaxiumBookingDuration() {
    	

    	WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(MaxiumBookingDuration));

        if (!checkbox.isSelected()) {
            checkbox.click();
        }
   }
    
    public boolean isSelectedMaxiumBookingDuration() {
    	
    	return isSelected(MaxiumBookingDuration);
    }
    
    public void enableToogle2(String value ) {
    	 WebElement textbox = wait.until(
    	            ExpectedConditions.visibilityOfElementLocated(Toogle2));

    	    textbox.clear();          // Removes the existing value

    	    textbox.sendKeys(value); 
    }
    
    
    public void ClickBookingPerDay() {
    	
    	WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(BookingPerDay));

        if (!checkbox.isSelected()) {
            checkbox.click();
        }
    }
    
    
    public boolean isSelectedBookingPerDay() {
    	
    	return isSelected(BookingPerDay);
    }
    
    
    public void enableToogle3(String value) {
    	 WebElement textbox = wait.until(
    	            ExpectedConditions.visibilityOfElementLocated(Toogle3));

    	    textbox.clear();          // Removes the existing value

    	    textbox.sendKeys(value); 
    }
    
    public void ClickMaximumAllowedPerDay() {
    	
    	WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(MaximumAllowedPerDay));

        if (!checkbox.isSelected()) {
            checkbox.click();
        }
    }
    
    
    public boolean isSelectedMaxiumAllowedPPerDay() {
    	
    	return isSelected(MaximumAllowedPerDay);
    }
    
    
    public void enableToogle4(String value ) {
    	
    	WebElement textbox = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(Toogle4));

	    textbox.clear();          // Removes the existing value

	    textbox.sendKeys(value); 
       
    }
        
    
    public void ClickMaxiumperiodAdvance() {
    	
    	WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(MaxiumperiodAdvance));

        if (!checkbox.isSelected()) {
            checkbox.click();
            
        }
    	
    }
    
    public boolean isSelected() {
    	
    	return isSelected(MaxiumperiodAdvance);
    }
    
    
    public void enableToogle5(String value) {
    	
    	WebElement textbox = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(Toogle5));

	    textbox.clear();          // Removes the existing value

	    textbox.sendKeys(value); 
        
        
    }
    
    
    public void ClickSubmit() {
    	 wait.until(ExpectedConditions.elementToBeClickable( Submit)).click();
    
    }

   
    public boolean isSubmitDisplayed() {
    	
    	 return wait.until(ExpectedConditions.visibilityOfElementLocated(Submit)).isDisplayed();
		 
    }
    }
    
    
        


