package StepDefinations;

import org.testng.Assert;

import POM.AdminPage;
import Utilities.ConfigReader;
import Utilities.DriverFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AdminStepDefinition {

    AdminPage admin;
    ConfigReader config = new ConfigReader();

    public AdminStepDefinition() {

        admin = new AdminPage(DriverFactory.getDriver());

    }

    @Given("User clicks Admin menu")
    public void user_clicks_Admin_menu() {

        admin.clickAdminMenu(
        		);

    }

    @Given("User clicks Organisation")
    public void user_clicks_organisation() {

        admin.clickOrganisation();

    }

    @When("User selects Time Zone")
    public void user_selects_time_zone() {

        admin.selectTimeZone(config.gettimeZone());

    }

    @When("User clicks Advanced Option")
    public void user_clicks_advanced_option() {

        admin.clickAdvancedOption();

    }

    @When("User enables Create User checkbox")
    public void user_enables_create_user_checkbox() {

        admin.enableCheckBox("adminPolicyCreateUsersIsDefined");

    }

    @When("User clicks Submit button")
    public void user_clicks_submit_button() {

        admin.clickSubmit();

    }

    @Then("Submit button should be displayed")
    public void submit_button_should_be_displayed() {

        Assert.assertTrue(admin.isDisplayedSubmit());

    }

}