package HookClass;

import Utilities.ConfigReader;
import Utilities.DriverFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class HookClass1 {

    ConfigReader config;

    @Before
    public void setup() {

        config = new ConfigReader();

        DriverFactory.initDriver();   // Initialize browser first

        DriverFactory.getDriver().get(config.getUrl());
    }

    @After
    public void tearDown() {

        DriverFactory.quitDriver();
    }
}