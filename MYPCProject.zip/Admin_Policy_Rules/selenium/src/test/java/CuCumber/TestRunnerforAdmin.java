package CuCumber;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;



@CucumberOptions(
		
	features="src/test/resources/Features",
	
glue= {"StepDefinations","HookClass"},

plugin=
{
"pretty",
"html:target/cucumber-report.html"
},

monochrome=true

)

public class TestRunnerforAdmin extends AbstractTestNGCucumberTests {

}



