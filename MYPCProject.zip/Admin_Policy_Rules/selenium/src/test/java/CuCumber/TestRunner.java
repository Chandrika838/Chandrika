package CuCumber;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(

    features = "src/test/resources/Features",

    glue = {"StepDefinations","HookClass"},

    plugin = {"pretty"},

    monochrome = true

)

public class TestRunner extends AbstractTestNGCucumberTests {

}