package CopyProperties;

import org.testng.annotations.Test;

import POM.BaseTest;
import POM.LoginPage;
import Utilities.ConfigReader;

public class RoomTestCase extends BaseTest{

	
	ConfigReader config = new ConfigReader();
	
	
	@Test 
	
	public void VerifyRoom() {
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		loginPage.enterPassword(config.getPassword());
		loginPage.clickLogin();
		
		
	RoomPage room = new RoomPage(driver);
	
	room.ClickAdmin();
	room.ClickTools();
	room.ClickRooms();
	room.ClickCopyProperties();
	room.SelectSource(config.getroomName());
	room.SelectLocation("All");
	
	String[] CheckBox ={
			
			//"tag_1e5fb244-c5ce-4126-88b6-019a2edd2d6c",
			"fd7f1a0b-23ae-4b15-9da8-019f40317e6e",
			"setting_LOCATION",
			"setting_DEFAULT_DURATION",
			"setting_CAPACITY",
			"setting_EQUIPMENT",
			"setting_EQUIPMENT",
			"setting_CHECK_IN_SETTINGS",
			"setting_TAGS"
			
	};
	
	for(String id : CheckBox) {
		
		room.enableCheckbox(id);
	}
		
		
	room.ClickCopy();	
		
		
	}
}
