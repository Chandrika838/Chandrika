package CopyProperties;

import org.testng.annotations.Test;

import POM.BaseTest;
import POM.LoginPage;
import Utilities.ConfigReader;

public class Location_TestCase extends BaseTest {

	ConfigReader  config = new ConfigReader();
	
	@Test
	
	public void verifylocation() {
	
	LoginPage loginPage = new LoginPage(driver);	
	
	loginPage.enterEmail(config.getEmail());
	
	loginPage.enterPassword(config.getPassword());

	loginPage.clickLogin();
	
	
	Locations location = new Locations(driver);
	
	location.clickAdmin();
	location.clickTools();
	location.clickLocations();
	location.clickCopyProperties();
	location.selectLocation("Testing");
	
    String[] checkBoxIds = {

    		"f21c5f59-0314-4c90-8c6c-019f26633948",
    		"setting_PARENT_LOCATION",
    		"setting_TIME_ZONE",
    		"setting_WORKING_HOURS",
    		
    };
	
    for (String id : checkBoxIds) {

        location.enableCheckbox(id);
    }

	
	location.clickCopy();
	
	
	}
}
