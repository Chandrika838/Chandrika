package Report;

import org.testng.annotations.Test;

import CopyProperties.UsersPage;
import POM.BaseTest;
import POM.LoginPage;
import Utilities.ConfigReader;

public class UsersTestCase extends BaseTest {

	ConfigReader config = new ConfigReader();
	
	@Test
	
	public void VerifyAddUserTest() {
		
	// creating a constructor for the login Page 
		
   LoginPage loginPage = new LoginPage(driver);
   
   loginPage.enterEmail(config.getEmail());
   loginPage.enterPassword(config.getPassword());
   loginPage.clickLogin();
   
   
   // creating an constructor for UserTest Case 
   
   UsersPage user = new UsersPage(driver);
   
   
   
	}
}
