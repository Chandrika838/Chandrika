package Report;

import org.testng.annotations.Test;

import POM.BaseTest;
import POM.LoginPage;
import ReportPages.DeskPage;
import Utilities.ConfigReader;

public class DeskTestCase extends BaseTest{

ConfigReader config = new ConfigReader();
	
	@Test
	
	public void VerifyAddDeskTest() {
		
	// creating a constructor for the login Page 
		
   LoginPage loginPage = new LoginPage(driver);
   
   loginPage.enterEmail(config.getEmail());
   loginPage.enterPassword(config.getPassword());
   loginPage.clickLogin();
   
   
// creating an constructor for UserTest Case 
   
   DeskPage desk = new DeskPage(driver);
   desk.ClickReport();
   desk.ClickDeskReport();
   desk.SelectLocation(config.getLocation());
   desk.SelectMonth(config.getperiod());
   desk.SelectBookingType(config.getBookingType());
}

}