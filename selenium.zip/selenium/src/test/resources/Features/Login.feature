Feature:Login Functionality 

Scenario:Login with valid credentails 
  
  Given User launche Chrome browser
  And User open the application 
  When User enter valid email
  And User enter valid password
  And User enable High Contrast
  And User click Login button
  Then User should login Successfully
  