Feature: Admin Module

Background:
  Given User launches Chrome browser
  And User open the application
  When User enters valid email
  And User enters valid password
  And User enable High Contrast
  And User clicks Login button
  Then User should login Successfully

Scenario: Verify Organisation Settings
  Given User clicks Admin menu
  And User clicks Organisation
  When User selects Time Zone
  And User clicks Advanced Option
  And User enables Create User checkbox
  And User clicks Submit button
  Then Organisation settings should be updated successfully


 
