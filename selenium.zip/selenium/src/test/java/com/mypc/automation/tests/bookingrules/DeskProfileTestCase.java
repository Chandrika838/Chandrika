package com.mypc.automation.tests.bookingrules;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.pages.bookingrules.DeskPage;
import com.mypc.automation.pages.bookingrules.DeskProfile;
import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.LoginPage;
import com.mypc.automation.utils.ConfigReader;

public class DeskProfileTestCase extends  BaseTest {

	
	ConfigReader config = new ConfigReader();
	
	@Test
	
	public void verifyAddDesk() {
		
		
		// creating construtor for loginPage
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		
		loginPage.enterPassword(config.getPassword());
		
		loginPage.clickLogin();
		
		// creating constructor for DeskProfile 
		
		DeskProfile Deskp = new DeskProfile(driver);
		
		Deskp.ClickAdmin();
		Deskp.ClickTools();
		Deskp.Clickcomputers();
		Deskp.Clickdeskprofile();
		Deskp.ClickAddnew();
		Deskp.SelectUsertags("Automation Tags");
		
		Assert.assertTrue(Deskp.isDisplayed(), "User Tags is not displayed");
		
		Deskp.SelectComputerstags("Computer_Tags");
		
		Assert.assertTrue(Deskp.isComputerDisplayed(),"Computer Tags is not displayed");
		
		
		Deskp.ClickCancel();
		
		Deskp.ClickContinue();
		
		Assert.assertTrue(Deskp.isContinueDisplayed(),"Continue is not displayed");
				
		
		
	}
}
