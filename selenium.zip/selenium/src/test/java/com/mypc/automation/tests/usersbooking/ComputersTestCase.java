package com.mypc.automation.tests.usersbooking;

import com.mypc.automation.pages.usersbooking.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.LoginPage;
import com.mypc.automation.utils.ConfigReader;

public class ComputersTestCase extends BaseTest {

	ConfigReader config = new ConfigReader();
	
	@Test
	
	public  void  verifyAddComputers() {
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		
		loginPage.enterPassword(config.getPassword());
		
		loginPage.clickLogin();
	
	
	ComputerPage Computers = new ComputerPage(driver);
	
	Computers.ClickAdmin();
	Computers.ClickTools();
	Computers.ClickUser();
	Computers.ClickBookingRules();
	Computers.ClickComputers();
	Computers.ClickAllusers();
	Computers.ClickAccess();
	
   Assert.assertTrue(Computers.isAccessDisplayed(),"Access is not Displayed");
   
	Computers.enablemaxiumBookingPerMonth("1000");
	
	Assert.assertTrue(Computers.ismaxiumBookingPerMonthDisplayed(),"Maxmium Booking per month is Displayed");
	
	Computers.enablemaxiumByDuration("20");
	
	Assert.assertTrue(Computers.ismaxiumByDurationDisplayed(),"Maxium By Duration Displayed");
	
	Computers.enableNumberofbooking("10");

	Computers.enableMaximumallowedperday("4");
	
	Assert.assertTrue(Computers.isMaximumaallowedperdayDisplayed(),"Maximum allowed per day");
	
	Computers.enableMaximunPeriodadvance("1450");
	
	Computers.ClickcanMake();
	
	Computers.enableMaxmium("3");
	
	Computers.ClickCanExtend();
	
	Computers.ClickcanMake();
	
	Computers.enablemaxmiumextendtime("50");
	
	Computers.ClickCancel();
	
	Computers.ClickSubmit();
	
	
	
	
	
	
	}
	

	}
	

