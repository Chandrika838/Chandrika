package com.mypc.automation.tests.copyproperties;

import com.mypc.automation.pages.copyproperties.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.LoginPage;
import com.mypc.automation.utils.ConfigReader;

public class Computer_TestCase extends BaseTest{

	ConfigReader config = new ConfigReader();
	
	@Test
	public void verifyAddComputer() {

	    LoginPage loginPage = new LoginPage(driver);

	    loginPage.enterEmail(config.getEmail());
	    loginPage.enterPassword(config.getPassword());
	    loginPage.clickLogin();

	    ComputersPage comp = new ComputersPage(driver);

	    comp.ClickAdmin();
	    comp.ClickTools();
	    comp.ClickComputers();
	    comp.clickBookingRules();
	    comp.Clicktags();

	    // Can Access
	    comp.ClickAccess();

	    // Maximum Bookings Per Month
	    comp.ClickMaximumPerMonth();
	    comp.enableToogle1("1");

	    // Maximum Booking Duration
	    comp.ClickMaxiumBookingDuration();
	    comp.enableToogle2("3");

	    // Number of Bookings Per Day
	    comp.ClickBookingPerDay();
	    comp.enableToogle3("2");

	    // Maximum Time Allowed Per Day
	    comp.ClickMaximumAllowedPerDay();
	    comp.enableToogle4("4");

	    // Maximum Days In Advance
	    comp.ClickMaxiumperiodAdvance();
	    comp.enableToogle5("5");

	    // Can Make Recurring
	    comp.ClickRecuuringBook();
	    
	    Assert.assertTrue(comp.isRecurringBookSelected(),"Recuuring book is not Selected");

	    // Max Recurring Days
	    comp.Clickrecurringbookings1();
	    comp.enableToogle7("5");

	    // Can Extend
	    comp.ClickExtension();
	    
	    Assert.assertTrue(comp.isExtensionSelected(), "Extension is not Selected");
	    
	    
	    // Save
	    comp.ClickSubmit();
	    
	    
	    Assert.assertTrue(comp.isSubmitDisplayed(),"Submit is not Displayed");

	}
	
}