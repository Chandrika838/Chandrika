package com.mypc.automation.tests.reports;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.LoginPage;
import com.mypc.automation.pages.reports.RoomReport;
import com.mypc.automation.utils.ConfigReader;

public class RoomReportTestCase extends BaseTest {

	ConfigReader config = new ConfigReader();
	
	@Test
	
	public void verifyAddRoomReportTestCase() {
		
		// creating a constructor for loginPage
		
	LoginPage loginPage = new LoginPage(driver);
	
	loginPage.enterEmail(config.getEmail());
	
	loginPage.enterPassword(config.getPassword());
	
	loginPage.clickLogin();
	
	
	// creating a constructor for RoomReport
	 
	RoomReport room = new RoomReport(driver);
	
	room.ClickReports();
	
	room.ClickUsers();
	
	room.SelectLocation(config.getLocation());
	
	Assert.assertTrue(room.isDisplayedLocation(),"Location is not Dsiplayed");
	room.Selectperiod(config.getperiod());
	
	Assert.assertTrue(room.isDisplayedperiod(),"period is not Dsiplayed");
	
	room.SelectBookingType(config.getBookingType());
	
	Assert.assertTrue(room.isDisplayedBookingType(), "Booking Type is not Dsiplayed");
	}
}
