package com.mypc.automation.tests.creatingtags;

import com.mypc.automation.pages.creatingtags.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.LoginPage;
import com.mypc.automation.utils.ConfigReader;

public class DeskTags_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();


    @Test
    public void verifyDeskTags() {

        LoginPage loginPage = new LoginPage(driver);

        loginPage.enterEmail(config.getEmail());
        loginPage.enterPassword(config.getPassword());
        loginPage.enableHighContrast();
        loginPage.clickLogin();

        Desk_Tags deskTags = new Desk_Tags(driver);

        deskTags.ClickAdmin();
        deskTags.ClickTools();
        deskTags.ClickDesk();
        deskTags.ClickTags();
        deskTags.ClickAddNew();

        String tagName = config.getDeskTagName();

        System.out.println("Tag Name = " + tagName);

        deskTags.enterDeskTags(tagName);

        deskTags.clickAdd();
   
    Assert.assertTrue(deskTags.isDisplayedSubmit(), "Submit is not Displayed");
    
    
    
    
    }
    
    
}