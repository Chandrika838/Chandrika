package com.mypc.automation.tests.bookingrulestags;

import com.mypc.automation.pages.bookingrulestags.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.LoginPage;
import com.mypc.automation.utils.ConfigReader;

public class ComputersTestCase extends BaseTest{
	
	ConfigReader config = new ConfigReader();
	
	
	@Test
	
	public void VerifyAddComputerTestCase(){
	
		
		// create the constructor for the loginPage
		
LoginPage loginPage = new LoginPage(driver);

loginPage.enterEmail(config.getEmail());
loginPage.enterPassword(config.getPassword());

loginPage.clickLogin();


// creating the constructor for the Room Test case


ComputersPage comp = new ComputersPage(driver); 
	
comp.ClickAdmin();

comp.ClickTools();
comp.ClickComputer();
comp.ClickTags();

comp.ClickTool();

comp.ClickBookingRules();


comp.ClickAddNew();

Assert.assertTrue(comp.isDisplayedAddNew(),"Add New is not Displayed");
		
comp.SelectID("Automation Tags");

comp.ClickDesk();
comp.ClickAddNew1();
comp.SelectID1("Automation Tags");


comp.ClickContinue();


Assert.assertTrue(comp.isDisplayedContinue(),"Continue is not Displayed");

comp.ClickUpdate();

Assert.assertTrue(comp.isDisplayedUpdate(),"Update is not Displayed");

comp.ClickUpdate1();


Assert.assertTrue(comp.isDisplayedUpdate1(),"Update1 is not Displayed ");


}
	


		
	}



