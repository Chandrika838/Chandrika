package com.mypc.automation.tests.reports;

import org.testng.annotations.Test;

import com.mypc.automation.pages.copyproperties.UsersPage;
import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.LoginPage;
import com.mypc.automation.utils.ConfigReader;

public class UsersTestCase extends BaseTest {

	ConfigReader config = new ConfigReader();
	
	@Test
	
	public void VerifyAddUserTest() {
		
	// creating a constructor for the login Page 
		
   LoginPage loginPage = new LoginPage(driver);
   
   loginPage.enterEmail(config.getEmail());
   loginPage.enterPassword(config.getPassword());
   loginPage.clickLogin();
   
   
   // creating an constructor for UserTest Case 
   
   UsersPage user = new UsersPage(driver);
   
   
   
	}
}
