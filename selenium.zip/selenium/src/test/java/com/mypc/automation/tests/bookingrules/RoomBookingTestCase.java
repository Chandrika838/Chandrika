package com.mypc.automation.tests.bookingrules;

import org.testng.annotations.Test;

import com.mypc.automation.pages.bookingrules.Room_BookingPage;
import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.LoginPage;
import com.mypc.automation.utils.ConfigReader;

public class RoomBookingTestCase  extends BaseTest{

	ConfigReader config = new ConfigReader();
	

	@Test
	
	public void verifyRoomBooking( ) {
		
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		loginPage.enterPassword(config.getPassword());
		loginPage.clickLogin();
		
		
		// method 
		
		Room_BookingPage  bookingPage = new Room_BookingPage(driver);
		
		bookingPage.clickAdmin();
		bookingPage.clickTools();
		bookingPage.clickRooms();
		bookingPage.clickBookingRules();
		bookingPage.clickAddNew();
		bookingPage.selectUserTag("Automation Tags");
		bookingPage.selectRoomTag("Automation");
		bookingPage.clickContinue();
		
	}
}
