package com.mypc.automation.tests;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.utils.ConfigReader;

public class UserTest extends BaseTest{
	
	ConfigReader config = new ConfigReader();
	
@Test

public void verifyUserSettings() {
	
	// creating a object for login page 
	
LoginPage loginPage = new LoginPage(driver);

loginPage.enterEmail(config.getEmail());
loginPage.enterPassword(config.getPassword());
loginPage.clickLogin();


UserPage userPage = new UserPage(driver);

	userPage.clickAdmnMenu();
	
	userPage.clickUserMenu();

	userPage.clickInviteUsers();
	
	userPage.enterFirstName(config.getFirstName());
	
	userPage.enterLastName(config.getLastName());
	
	
	Assert.assertTrue(userPage.isDisplayed(),"Submit is not displaye ");
	
	userPage.clickSubmit();
	
	
	
}
	
}
