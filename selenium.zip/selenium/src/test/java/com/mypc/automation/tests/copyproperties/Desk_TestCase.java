package com.mypc.automation.tests.copyproperties;

import com.mypc.automation.pages.copyproperties.*;

import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.LoginPage;
import com.mypc.automation.utils.ConfigReader;

public class Desk_TestCase  extends BaseTest{

	ConfigReader config =new ConfigReader();
	
	@Test
	
	public void verifyDesk() {
		
		LoginPage loginPage = new LoginPage(driver);
		
		loginPage.enterEmail(config.getEmail());
		
		loginPage.enterPassword(config.getPassword());
		
		loginPage.clickLogin();
		
		
	// methods 
		
	DeskPage Desk =new DeskPage(driver);
	
	Desk.ClickAdmin();
	Desk.ClickTools();
	Desk.ClickDesk();
	Desk.ClickCopyProperties();
	Desk.SelectSource(config.getDeskName());
	Desk.SelectLocation(config.getLocation());
	
	// Authenatication checkobx 
	
	String[] CheckBox ={
		
		"tag_c95219e7-b1aa-4b2b-9efb-019f5c11cb30",
		"setting_LOCATION",
		"setting_DEFAULT_DURATION",
		"setting_PREPARATION_TIME",
		"setting_CHECK_IN_SETTINGS",
		"setting_TAGS",
		
	};
	
	for(String id : CheckBox) {
		
		Desk.enableCheckbox(id);
	}
	
		
		
	Desk.ClickCopy();	
		
		
		
	}
}
