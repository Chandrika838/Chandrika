package com.mypc.automation.tests;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.*;

import org.testng.annotations.Test;

import com.mypc.automation.utils.ConfigReader;

public class Tools_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyAddTools() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(config.getEmail(), config.getPassword());

        // Tools Page
        ToolsPage toolsPage = new ToolsPage(driver);

        toolsPage.Clickadmin();

        toolsPage.ClickTools();

        toolsPage.ClickUsers();

        toolsPage.ClickTags();

        toolsPage.Clickaddnew();

        toolsPage.enterTagName("Automation Tags");

        toolsPage.clickAdd();
    }
}
