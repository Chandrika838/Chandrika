package com.mypc.automation.tests.copyproperties;

import com.mypc.automation.pages.copyproperties.*;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.LoginPage;
import com.mypc.automation.utils.ConfigReader;

public class UsersTestCase extends BaseTest {

	ConfigReader config = new ConfigReader();
	


@Test


public void verifyAddUsers() {
	
	LoginPage loginPage = new LoginPage(driver);
	
	loginPage.enterEmail(config.getEmail());
	loginPage.enterPassword(config.getPassword());
	loginPage.clickLogin();
	
	
 UsersPage Users = new UsersPage(driver);

Users.clickAdmin();
Users.clickTools();
Users.ClickUsers();
Users.ClickCopyProperties();


// Authenatic checkboxes

String[] Checkbox = {
	
		"tag_b28410dd-7332-42f6-9863-019f501d4b97",
		"setting_USER_ROLE",
		"setting_TAGS",
};
		 for (String id : Checkbox) {

	            Users.enableCheckbox(id);
	        }


Users.clickCopy();

	
}

	
	
}
	
	
	


