package com.mypc.automation.tests;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.utils.ConfigReader;

public class Reserve_Desk_TestCase extends BaseTest {

    ConfigReader config = new ConfigReader();

    @Test
    public void verifyAddDeskReserve() {

        // Login
        LoginPage loginPage = new LoginPage(driver);

        loginPage.login(config.getEmail(), config.getPassword());

        // Reserve Desk Page
        Reserve_DeskPage deskPage = new Reserve_DeskPage(driver);

        deskPage.ClickReserve();

        deskPage.ClickDesk();

        deskPage.SelectLocation(config.getLocation());
        
        Assert.assertTrue(deskPage.isDisplayedLocation(), "Location is not displayed ");
        
        deskPage.selectDate("Aug 2026", "5");
        

        deskPage.ClickToolTip();
        
        Assert.assertTrue(deskPage.isDisplayedToolTip(), "Tool Tip is not Displayed ");

        deskPage.SelectStartTime1(config.getStartTime1());
        
        Assert.assertTrue(deskPage.isDisplayedStartTime1(), "Start Time is not Displayed ");

        deskPage.ClickDragDrop();

        deskPage.enableSelfBooking();
        
        Assert.assertTrue(deskPage.isDisplayedSelfBooking(), "Self Booking is not Displayed ");

        deskPage.ClickBook();
        
        Assert.assertTrue(deskPage.isDisplayedBook(), "Book is not Displayed");
    }
}