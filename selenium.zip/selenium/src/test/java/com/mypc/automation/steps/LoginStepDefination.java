package com.mypc.automation.steps;

import org.testng.Assert;

import com.mypc.automation.pages.LoginPage;
import com.mypc.automation.utils.ConfigReader;
import com.mypc.automation.utils.DriverFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefination {

    LoginPage login;
    ConfigReader config = new ConfigReader();

    @Given("User launche Chrome browser")
    public void user_launche_chrome_browser() {

        login = new LoginPage(DriverFactory.getDriver());

    }

    @Given("User open the application")
    public void user_open_the_application() {

        // Already opened in Hooks

    }

    @When("User enter valid email")
    public void user_enter_valid_email() {

        login.enterEmail(config.getEmail());

    }

    @When("User enter valid password")
    public void user_enter_valid_password() {

        login.enterPassword(config.getPassword());

    }

    @When("User enable High Contrast")
    public void user_enable_high_contrast() {

        login.enableHighContrast();

    }

    @When("User click Login button")
    public void user_click_login_button() {

        login.clickLogin();

    }

    @Then("User should login Successfully")
    public void user_should_login_successfully() {

        Assert.assertTrue(login.isDisplayedLogin());

    }

}

