package com.mypc.automation.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;



@CucumberOptions(
		
	features="src/test/resources/Features",
	
glue = {"com.mypc.automation.steps", "com.mypc.automation.hooks"},

plugin=
{
"pretty",
"html:target/cucumber-report.html"
},

monochrome=true

)

public class TestRunnerforAdmin extends AbstractTestNGCucumberTests {

}



