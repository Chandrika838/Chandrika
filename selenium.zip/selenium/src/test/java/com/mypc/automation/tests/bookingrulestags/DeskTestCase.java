package com.mypc.automation.tests.bookingrulestags;

import com.mypc.automation.pages.bookingrulestags.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.LoginPage;
import com.mypc.automation.utils.ConfigReader;

public class DeskTestCase  extends BaseTest {

	
	ConfigReader config = new ConfigReader();
	
	
	@Test
	
	public void VerifyDeskTestCase() {
		
		
		LoginPage loginPage = new LoginPage(driver);

		loginPage.enterEmail(config.getEmail());
		loginPage.enterPassword(config.getPassword());

		loginPage.clickLogin();


		// creating the constructor for the Room Test case


		DeskPage desk = new DeskPage(driver); 
			
		desk.ClickAdmin();

		desk.ClickTools();
		desk.ClickDesk();
		desk.ClickTags();

		desk.ClickTool();

		desk.ClickBookingRules();


		desk.ClickAddNew();

		Assert.assertTrue(desk.isDisplayedAddNew(),"Add New is not Displayed");
				
		desk.SelectID("Automation Tags");

		desk.ClickContinue();


		Assert.assertTrue(desk.isDisplayedContinue(),"Continue is not Displayed");

		desk.ClickUpdate();

		Assert.assertTrue(desk.isDisplayedUpdate(),"Update is not Displayed");

		desk.ClickUpdate1();


		Assert.assertTrue(desk.isDisplayedUpdate1(),"Update1 is not Displayed ");


		}
			}

	
	

