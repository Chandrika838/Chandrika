package com.mypc.automation.tests;

import com.mypc.automation.base.BaseTest;
import com.mypc.automation.pages.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mypc.automation.utils.ConfigReader;

public class LoginTestCase extends BaseTest {
	
	ConfigReader config = new ConfigReader();


	@Test
	public void verifyValidLogin (){

		LoginPage loginPage = new LoginPage(driver);

	    loginPage.enterEmail(config.getEmail());

	    loginPage.enterPassword(config.getPassword());

	    loginPage.enableHighContrast();
	    
	    Assert.assertTrue(loginPage.isHighContrastEnabled(), "Enable is not High Constrast");
	   
	    loginPage.clickLogin();

	    DashboardPage dashboardPage = new DashboardPage(driver);

	    Assert.assertTrue(
	            dashboardPage.isLoggedInUserNameDisplayed(),
	            "Logged-in user name is not displayed on the dashboard");
	    Assert.assertFalse(
	            dashboardPage.getLoggedInUserName().isEmpty(),
	            "Logged-in user name is empty");
	
	}
	}
