package com.mypc.automation.tests.userlogin;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class User_LoginPage {

	WebDriver driver;
	WebDriverWait wait;
	
	@BeforeMethod
	
	public void setup() {
		
		driver = new ChromeDriver();
		
		
	driver.manage().window().maximize();
	
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	
	wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		
	driver.get("https://rezzqa5.its-cs.com/Auth/Login");
	
	}
	
	@Test
	
	public void LoginPage() {
		
driver.findElement(By.cssSelector("#email")).sendKeys("c3834717@gmail.com");
driver.findElement(By.cssSelector("#password")).sendKeys("Automation@123");
		
	WebElement checkbox  =driver.findElement(By.id("highContrastSwitch"));
	
if(!checkbox.isSelected()) {
	
	checkbox.click();
	
}
	
Assert.assertTrue(driver.findElement(By.id("highContrastSwitch")).isSelected(), "High Contrast Swtich is not seleccted");
		
driver.findElement(By.cssSelector(".btn.btn-default.btn-login.btn-main")).click();
		
		// setting 
		

Assert.assertTrue(
		driver.findElement(By.cssSelector(".btn.btn-default.btn-login.btn-main")).isDisplayed(),
		"Login button is not visible"
			);
	

//Navigate to Reserve
		driver.findElement(By.xpath("//span[normalize-space()='Reserve']")).click();

		
		// Click Computers
		driver.findElement(By.xpath("//span[normalize-space()='Computers']")).click();

		
		// Select dropdown
		WebElement dropdown = driver.findElement(By.cssSelector("select"));
		Select select = new Select(dropdown);
		select.selectByVisibleText("Selenium123");
		
//calendar 
	
		WebElement calendar  = wait.until(
		        ExpectedConditions.elementToBeClickable(By.xpath("//span[@role='button']")));
		
		calendar.click();
		
		Assert.assertTrue(calendar.isEnabled(),
		        "Calendar is not enabled");
		
		
		
	Assert.assertTrue(calendar.isDisplayed(),"Calendar is not selected");
		



	By bookingStrip = By.xpath("//div[@role='button']");

	WebElement tooltip = wait.until(
	        ExpectedConditions.elementToBeClickable(
	                bookingStrip));

	tooltip.click();
	

	//timing 

WebElement startTime = wait.until(
     ExpectedConditions.visibilityOfElementLocated(
             By.xpath("//app-time-selector[@formcontrolname='startTime']//select")));

Select time = new Select(startTime);

time.selectByVisibleText("12:10 PM");
	
	
//self booking 

WebElement selfBooking =driver.findElement(By.id("selfBooking"));
	
if (!selfBooking.isSelected()) {
	selfBooking.click();

}

Assert.assertTrue(selfBooking.isSelected(),"SelfBooking is not Selected");

	
//booking 


WebElement Booking= wait.until(
     ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));


Booking.click();


Assert.assertTrue(Booking.isDisplayed(),"Booking is not display");

	}
	
	@AfterMethod
	public void closeBrowser() {
		driver.quit();
	}



	
	}
	

