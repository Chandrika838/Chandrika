package com.mypc.automation.base;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.mypc.automation.utils.ConfigReader;

public class BaseTest {

	protected WebDriver driver;

    protected ConfigReader config = new ConfigReader();

@BeforeMethod

public void setup() {
	
 driver = new ChromeDriver();
	 
driver.manage().window().maximize();

driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(40));
	 
	 
driver.get("https://rezzqa6.its-cs.com/Auth/Login?returnUrl=%2FDashboard");

 }

 @AfterMethod(alwaysRun = true)
 public void tearDown() {

     if (driver != null) {
         driver.quit();
         driver = null;
     }
 }
}	 
	 
	 
	 
	 
 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 

 

