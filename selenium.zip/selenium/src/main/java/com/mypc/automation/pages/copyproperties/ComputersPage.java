package com.mypc.automation.pages.copyproperties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.mypc.automation.pages.BasePage;

public class ComputersPage extends BasePage{
	
	public ComputersPage(WebDriver driver){
		
		super(driver);
		
		// locators 
	}
	
	private By admin = 
			By.xpath("//span[normalize-space()='Admin']");
	
	
	private By Tools = 
			By.xpath("//span[normalize-space()='Tools']");
	
	private By Computers = 
			By.xpath("//button[normalize-space()='Computer Tools']");
	
	
	private By BookingRules =
		     By.cssSelector("div[class='collapse show'] button:nth-child(4)");
	
	
	private By Tags = 
			By.xpath("//span[@title='Automation Tags']");
	
	
   private By Access = 
		   By.id("canAccessIsDefined");
   
   private By Toogle =
		   
		   By.id("canAccess");
    
    private By MaxiumPerMonth = 
    		By.id("maximumNumberOfBookingsPerMonthIsDefined");
    
    private By Toogle1 = 
    		By.id("maximumNumberOfBookingsPerMonth");
    
    private By MaxiumBookingDuration = 
    		By.cssSelector("#maximumBookingDurationIsDefined");
    
    private By Toogle2 = 
    		By.id("maximumBookingDuration");
    
    private By BookingPerDay =
    		By.id("numberOfBookingsPerDayIsDefined");
    
    private By Toogle3=
    		By.id("numberOfBookingsPerDay");
    
    
    private By MaximumAllowedPerDay =
    		By.cssSelector("#maximumTimeAllowedPerDayIsDefined");
    
    private By Toogle4 = 
    		By.id("maximumTimeAllowedPerDay");
    
    private By MaxiumperiodAdvance=
    		By.cssSelector("#maxDaysInAdvanceIsDefined");
    
    private By Toogle5 =
    		By.id("maxDaysInAdvance");
    
    private By recuuringBooks =
    		By.id("canMakeRecurringIsDefined");
    
    private By Toogle6 =
    		By.id("canMakeRecurringIsDefined");
    
    
    private By recurringbookings =
    		By.id("maxRecurringDaysInAdvanceIsDefined");
    
    
    private By Toogle7 =
    		
    		By.id("maxRecurringDaysInAdvance");
    
    
    private By extendssession = 
    		By.id("canExtendIsDefined");
    
      
    private By Toogle8 =
    		By.id("canExtend");
    
    
    private By Cancel = 
    		By.xpath("//button[normalize-space()='Cancel']");
    	
  
    private By Submit = 
 		   By.cssSelector("button[type='submit']");
    
    
    
    public void ClickAdmin() {
    	 wait.until(ExpectedConditions.elementToBeClickable(admin)).click();
    }
    
    public void ClickTools() {
        wait.until(ExpectedConditions.elementToBeClickable(Tools)).click();
    }
    
    
    public void ClickComputers() {
    	
    	 wait.until(ExpectedConditions.elementToBeClickable(Computers)).click();
    }


    
    public void clickBookingRules() {
        wait.until(ExpectedConditions.elementToBeClickable(BookingRules)).click();
    }

    
    
    public void Clicktags() {
    	wait.until(ExpectedConditions.elementToBeClickable(Tags)).click();
    }
    	
    
    
    public void ClickAccess() {
    	
    	WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(MaxiumPerMonth));

        if (!checkbox.isSelected()) {
            checkbox.click();
        }  
    	
    }
    
    
    public void enableToogle(String value) {
    	
    	 WebElement textbox = wait.until(
 	            ExpectedConditions.visibilityOfElementLocated(Toogle));

 	    textbox.clear();          // Removes the existing value

 	    textbox.sendKeys(value); 
 
 }
 
    	
    
    
    		
    public void ClickMaximumPerMonth() {
    	
    WebElement checkbox = wait.until(
            ExpectedConditions.elementToBeClickable(MaxiumPerMonth));

    if (!checkbox.isSelected()) {
        checkbox.click();
    }  

}
    
    
    public void enableToogle1(String value ) {
    	
    	 WebElement textbox = wait.until(
    	            ExpectedConditions.visibilityOfElementLocated(Toogle1));

    	    textbox.clear();          // Removes the existing value

    	    textbox.sendKeys(value); 
    
    }
    
    public void ClickMaxiumBookingDuration() {
    	

    	WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(MaxiumBookingDuration));

        if (!checkbox.isSelected()) {
            checkbox.click();
        }
   }
    
    
    public void enableToogle2(String value ) {
    	 WebElement textbox = wait.until(
    	            ExpectedConditions.visibilityOfElementLocated(Toogle2));

    	    textbox.clear();          // Removes the existing value

    	    textbox.sendKeys(value); 
    }
    
    
    public void ClickBookingPerDay() {
    	
    	WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(BookingPerDay));

        if (!checkbox.isSelected()) {
            checkbox.click();
        }
    }
    
    
    public void enableToogle3(String value) {
    	 WebElement textbox = wait.until(
    	            ExpectedConditions.visibilityOfElementLocated(Toogle3));

    	    textbox.clear();          // Removes the existing value

    	    textbox.sendKeys(value); 
    }
    
    
    public void ClickMaximumAllowedPerDay() {
    	
    	WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(MaximumAllowedPerDay));

        if (!checkbox.isSelected()) {
            checkbox.click();
        }
    }
    
    
    public void enableToogle4(String value ) {
    	
    	WebElement textbox = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(Toogle4));

	    textbox.clear();          // Removes the existing value

	    textbox.sendKeys(value); 
       
    }
        
    
    public void ClickMaxiumperiodAdvance() {
    	
    	WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(MaxiumperiodAdvance));

        if (!checkbox.isSelected()) {
            checkbox.click();
            
        }
    	
    }
    
    public void enableToogle5(String value) {
    	
    	WebElement textbox = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(Toogle5));

	    textbox.clear();          // Removes the existing value

	    textbox.sendKeys(value); 
        
        
    }
    
    
    
    public void ClickRecuuringBook() {
    	
    	WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(MaxiumperiodAdvance));

        if (!checkbox.isSelected()) {
            checkbox.click();
            
        }
    }
    
    
    public boolean isRecurringBookSelected() {
    	
    	return isSelected(recurringbookings);
    }
    
    public void enableToogle6(String value) {
    	
    	WebElement textbox = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(Toogle6));

	    textbox.clear();          // Removes the existing value

	    textbox.sendKeys(value);
    	
    }
    
    
     public void Clickrecurringbookings1() {
    	
    	WebElement checkbox = wait.until(
                ExpectedConditions.elementToBeClickable(recurringbookings));

        if (!checkbox.isSelected()) {
            checkbox.click();
            
        }
    
}


     public void enableToogle7(String value) {
    	 
    	 
     WebElement textbox = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(Toogle7));

	    textbox.clear();          // Removes the existing value

	    textbox.sendKeys(value); 
}
     
     
     
     public void ClickExtension() {
    	 

     	WebElement checkbox = wait.until(
                 ExpectedConditions.elementToBeClickable(extendssession));

         if (!checkbox.isSelected()) {
             checkbox.click();
             
         } 
     }


     public boolean isExtensionSelected() {
    	 
    	 return isSelected(extendssession);
     }
     
     public void enableToogle8(String value ) {
    	 
    	 
         WebElement textbox = wait.until(
    	            ExpectedConditions.visibilityOfElementLocated(Toogle8));

    	    textbox.clear();          // Removes the existing value

    	    textbox.sendKeys(value); 
    	 
    	 
     }
     
     
     public void ClickCancel() {
    	 
    	 wait.until(ExpectedConditions.elementToBeClickable(Cancel)).click();
     }
    
    public void ClickSubmit() {
    	 wait.until(ExpectedConditions.elementToBeClickable( Submit)).click();
    
    }

    public boolean isSubmitDisplayed() {
    	
    	return isDisplayed(Submit);
    }
    
    
    }

