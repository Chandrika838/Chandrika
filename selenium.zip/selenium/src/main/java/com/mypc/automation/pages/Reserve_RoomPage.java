package com.mypc.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class Reserve_RoomPage extends BasePage{

	public Reserve_RoomPage(WebDriver driver) {
	
	super(driver);
	
	}	
	// locators 
	

private By reserve = 
        By.xpath("//span[normalize-space()='Reserve']");

private By room = 
        By.xpath("//span[normalize-space()='Room']");

private By location = 
        By.xpath("//app-location-selector//select");


private By datePicker = 
        By.cssSelector("span[role='button']");

private By nextButton = 
        By.xpath("//button[@title='Next month']");


private By MonthYear = 
        By.xpath("//div[@class='ngb-dp-month-name']");
	
private By tooltip = 
        By.cssSelector("div[role='button']");
        		

private By startTime = 
        By.xpath("//app-time-selector[@formcontrolname='startTime']//select");

private	 By dragDrop = 
         By.xpath("//div[@class='bs bs-marker']");
	
private By selfBooking = 
        By.id("selfBooking");	
	
private By Submit= 
        By.xpath("//span[normalize-space()='Book']");	
	

// methods 
	

public void clickReserve() {
	
	wait.until(ExpectedConditions.elementToBeClickable(reserve)).click();	
	
}

public void clickRoom() {
	
	wait.until(ExpectedConditions.elementToBeClickable(room)).click();
}

public void selectLocation(String value ){
	
	Select select = new Select(getElement(location));
	
	select.selectByVisibleText(value);
}
	

public boolean isDisplayedLocation() {
	
	return isDisplayed(location);
}



public void selectDate(String expectedMonthYear, String expectedDay) {

    // Open calendar
    wait.until(ExpectedConditions.elementToBeClickable(datePicker)).click();

    // Navigate until expected month appears
    while (true) {

        String currentMonth = wait.until(
                ExpectedConditions.visibilityOfElementLocated(MonthYear))
                .getText().trim();
        

        // Add these two lines here
        System.out.println("Current Month : " + currentMonth);
        System.out.println("Expected Month : " + expectedMonthYear);

        
        if (currentMonth.equals(expectedMonthYear)) {
            break;
        }
        

        wait.until(ExpectedConditions.elementToBeClickable(nextButton)).click();
    }
    

    // Select the required date
    By day = By.xpath(
            "//div[contains(@class,'ngb-dp-day') and not(contains(@class,'disabled'))]//div[normalize-space()='"
                    + expectedDay + "']");

    WebElement date = wait.until(
            ExpectedConditions.elementToBeClickable(day));

    date.click();
}

	
public void clickToolTip() {
	
    WebElement tooltipElement = wait.until(
            ExpectedConditions.refreshed(
                    ExpectedConditions.elementToBeClickable(tooltip)));

    tooltipElement.click();
    
    
}


public boolean isDisplayedTooltips() {
	
	return isDisplayed(tooltip);
	
}



public void selectStartime(String value) {
	

    // Wait until the dropdown is visible
    WebElement dropdown = wait.until(
            ExpectedConditions.visibilityOfElementLocated(startTime));

    // Wait until the dropdown is clickable
    wait.until(ExpectedConditions.elementToBeClickable(dropdown));

    // Create Select object
    Select select = new Select(dropdown);

    
    // Select the value
    select.selectByVisibleText(value);
}


public void clickDragdrop() {
	
	WebElement element = getElement(dragDrop);
	
	new Actions(driver).dragAndDropBy(element, 15, 0).perform();

}

public void enableSelfBooking() {
	
	WebElement checkbox = getElement(selfBooking);
	
	if(!checkbox.isSelected()) {
		
		checkbox.click();
	}
	
}


public boolean isSelectedSelfBooking() {
	
	return isSelected(selfBooking);
	
}


public void clickSubmit() {
	WebElement button = wait.until(
            ExpectedConditions.elementToBeClickable(Submit));
	button.click();

}

public boolean isDisplayedBooks() {
	
	return isDisplayed(Submit);
}

}
