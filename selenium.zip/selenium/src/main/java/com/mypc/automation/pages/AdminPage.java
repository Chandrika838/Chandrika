package com.mypc.automation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;


public class AdminPage extends BasePage {

	public AdminPage(WebDriver driver) {
		super(driver);
		
	}


// locators 
	 // here we need to write alll the main main things in the adminpage of java 
	
private	By adminMenu = By.xpath("//span[contains(text(),'Admin')]");

private By organisation = By.xpath("//span[contains(text(),'Organisation')]");

private By timeZone = By.xpath("//app-time-zone-selector//select");

private By advancedOption = By.xpath("//button[normalize-space()='advanced options']");

private	By submitButton = By.cssSelector("button[type='submit']");

// Admin mwthods
	
	public void clickAdminMenu() {
		 wait.until(ExpectedConditions.elementToBeClickable(adminMenu)).click();
	}

 
// organisation 
	
	public void clickOrganisation() {
	
		 wait.until(ExpectedConditions.elementToBeClickable(organisation)).click();
	}
		
	

// Time Zone 
	
public void selectTimeZone(String value) {
	
	Select select = new Select(getElement (timeZone));
	select.selectByVisibleText(value);
	
}


public boolean  isTimeZoneDisplayed() {
	
	return isDisplayed (timeZone);
	
	
}
// Advanced Option 

public void clickAdvancedOption() {
	
	click(advancedOption);
}



// check box 


public void enableCheckBox(String id) {
	
	By locator = By.id(id);
	
	if(!getElement(locator).isSelected()) {
		
		click(locator);
	}

	}




// Submit button 

public void clickSubmit() {
	
	click(submitButton);
	
}


	public boolean isDisplayedSubmit() {
		
		return isDisplayed(submitButton);
	
}


}









