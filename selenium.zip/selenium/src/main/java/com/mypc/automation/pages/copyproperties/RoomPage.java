package com.mypc.automation.pages.copyproperties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.mypc.automation.pages.BasePage;

public class RoomPage  extends BasePage{

	public RoomPage(WebDriver driver) {
		
		super(driver);
		
	}
	
	
// locators 
	
	private By admin =
            By.xpath("//span[normalize-space()='Admin']");

    private By tools =
            By.xpath("//span[normalize-space()='Tools']");
    
    
    private By Tools = 
    		By.xpath("//button[normalize-space()='Room Tools']");
    
    
    private By CopyProperties =
    		By.cssSelector("div[class='collapse show'] button:nth-child(2)");
    
    
    private By Source = 
    		By.xpath("//select[@formcontrolname='sourceId']");
    
    
    
    private By location = 
    		By.xpath("//select[@id='selectedLocationId']");
    
    
   // private By Tags = 
    	//	By.id("tag_1e5fb244-c5ce-4126-88b6-019a2edd2d6c");
    
    private By Target = 
    		By.id("fd7f1a0b-23ae-4b15-9da8-019f40317e6e");
    
    private By Setting = 
    		By.id("setting_LOCATION");
    
    private By Default = 
    		By.id("setting_DEFAULT_DURATION");
    
    private By Capacity = 
    		By.id("setting_CAPACITY");
    
    
    private By equipment = 
    		By.id("setting_EQUIPMENT");
    
    
    private By prepartionontime =
    		
    		By.id("setting_EQUIPMENT");
    
    
    private By checkinsetting =
    		By.id("setting_CHECK_IN_SETTINGS");
    
    
    private By Tags1 =
    		By.id("setting_TAGS");
    
    
    private By Copy = 
    		By.cssSelector("button[type='submit']");
    
    // Methods 
    
    
 public void ClickAdmin() {
    	
    	wait.until(ExpectedConditions.elementToBeClickable(admin)).click();
    }
    
    public void ClickTools() {
    	
    	wait.until(ExpectedConditions.elementToBeClickable(tools)).click();
    }

    
  public void ClickRooms() {
	  
	  wait.until(ExpectedConditions.elementToBeClickable(Tools)).click();
  }
    
    
    
 public void ClickCopyProperties() {
	 
	 wait.until(ExpectedConditions.elementToBeClickable(CopyProperties)).click();
 }
    
    
   public void SelectSource(String value) {
	   
	   WebElement dropdown = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(Source));

	    Select select = new Select(dropdown);
	    select.selectByVisibleText(value);
   }
    
    
   public void SelectLocation(String value ) {
	   
	   WebElement dropdown = wait.until(
	            ExpectedConditions.visibilityOfElementLocated(location));

	    Select select = new Select(dropdown);
	    select.selectByVisibleText("All");
	   
	  
   }
   
   public void enableCheckbox(String id) {

	    By locator = By.id(id);

	    WebElement checkbox = wait.until(
	            ExpectedConditions.elementToBeClickable(locator));

	    if (!checkbox.isSelected()) {
	        checkbox.click();
	    }
	}



public void ClickCopy() {

	 wait.until(ExpectedConditions.elementToBeClickable(Copy)).click();
}
}
